# ABDM V3 API Postman Collection

[![ABDM V3 APIs](https://img.shields.io/badge/ABDM-V3%20APIs-blue)](https://sandbox.abdm.gov.in)
[![Last Updated](https://img.shields.io/badge/Last%20Updated-March%202026-green)](https://github.com/Nirmitee-tech/abdm-v3-postman-collection)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Complete Postman collection for all ABDM (Ayushman Bharat Digital Mission) V3 API endpoints. Covers M1 (ABHA creation), M2 (HIP services), and M3 (HIU services) milestones with pre-configured sandbox and production environments.

Maintained by [Nirmitee.io](https://nirmitee.io) — healthcare integration specialists.

---

## Quick Start

1. **Import the collection** into Postman:
   - Download `collections/ABDM-V3-Complete.postman_collection.json`
   - In Postman, click **Import** and select the file

2. **Import the environment**:
   - Download `environments/ABDM-V3-Sandbox.postman_environment.json`
   - In Postman, click **Import** and select the file

3. **Configure credentials**:
   - Select the **ABDM V3 — Sandbox** environment
   - Set `clientId` (your SBXID) and `clientSecret`
   - Set `hipId` and `hiuId` with your facility IDs

4. **Start testing** — the collection auto-authenticates before each request.

See [docs/SETUP.md](docs/SETUP.md) for detailed setup instructions.

## What's Included

### Collections

| Collection | File | Endpoints |
|---|---|---|
| **Complete** (recommended) | `ABDM-V3-Complete.postman_collection.json` | All 30+ endpoints |
| M1 — ABHA | `ABDM-V3-M1-ABHA.postman_collection.json` | Enrollment, login, profile |
| M2 — HIP | `ABDM-V3-M2-HIP.postman_collection.json` | Discovery, linking, consent, data flow |
| M3 — HIU | `ABDM-V3-M3-HIU.postman_collection.json` | Consent management, data requests |

### Environments

| Environment | File |
|---|---|
| Sandbox | `ABDM-V3-Sandbox.postman_environment.json` |
| Production | `ABDM-V3-Production.postman_environment.json` |

## V3 Endpoint Status (March 2026)

Based on real integration testing in the ABDM sandbox:

### Authentication
| Endpoint | Method | Status |
|---|---|---|
| `/gateway/v3/sessions` | POST | Working |

### M1 — ABHA Creation & Verification
| Endpoint | Method | Status |
|---|---|---|
| `/v3/enrollment/request/otp` | POST | Working |
| `/v3/enrollment/enrol/byAadhaar` | POST | Working |
| `/v3/enrollment/enrol/byAbdm` | POST | Working |
| `/v3/profile/login/request/otp` | POST | Working |
| `/v3/profile/login/verify` | POST | Working |
| `/v3/profile/account/getAbhaCard` | POST | Working |

### M2 — Discovery & Linking
| Endpoint | Direction | Status |
|---|---|---|
| `/api/v3/hip/patient/care-context/discover` | Gateway -> HIP | Working |
| `/user-initiated-linking/v3/patient/care-context/on-discover` | HIP -> Gateway | Working |
| `/api/v3/hip/link/care-context/init` | Gateway -> HIP | Working |
| `/user-initiated-linking/v3/link/care-context/on-init` | HIP -> Gateway | Working |
| `/api/v3/hip/link/care-context/confirm` | Gateway -> HIP | Working |
| `/user-initiated-linking/v3/link/care-context/on-confirm` | HIP -> Gateway | Working |

### M2 — HIP-Initiated Linking
| Endpoint | Direction | Status |
|---|---|---|
| `/v3/token/generate-token` | HIP -> Gateway | 403 |
| `/hip/v3/link/carecontext` | HIP -> Gateway | 403 |
| `/hip/v3/link/context/notify` | HIP -> Gateway | 403 |
| `/hip/v3/link/patient/links/sms/notify2` | HIP -> Gateway | 403 |

### M2 — Consent (HIP Side)
| Endpoint | Direction | Status |
|---|---|---|
| `/api/v3/consent/request/hip/notify` | Gateway -> HIP | Working |
| `/consent/v3/request/hip/on-notify` | HIP -> Gateway | Working |

### M2 — Data Flow
| Endpoint | Direction | Status |
|---|---|---|
| `/api/v3/hip/health-information/request` | Gateway -> HIP | 403 |
| `/data-flow/v3/health-information/hip/on-request` | HIP -> Gateway | 403 |
| `/data-flow/v3/health-information/notify` | HIP -> Gateway | 403 |

### M2 — Profile Share
| Endpoint | Direction | Status |
|---|---|---|
| `/api/v3/hip/patient/share` | Gateway -> HIP | Working |
| `/patient-share/v3/on-share` | HIP -> Gateway | 403 |

### M2 — Bridge Management
| Endpoint | Method | Status |
|---|---|---|
| `/gateway/v3/bridge/url` | PATCH | 403 (CloudFront WAF) |
| `/gateway/v3/bridge/getServices` | GET | Working |

### M3 — Consent (HIU Side)
| Endpoint | Direction | Status |
|---|---|---|
| `/consent/v3/request/init` | HIU -> Gateway | Working |
| `/api/v3/hiu/consent/request/on-init` | Gateway -> HIU | Working |
| `/consent/v3/request/status` | HIU -> Gateway | Working |
| `/api/v3/hiu/consent/request/on-status` | Gateway -> HIU | Working |
| `/consent/v3/fetch` | HIU -> Gateway | Working |
| `/api/v3/hiu/consent/on-fetch` | Gateway -> HIU | Working |
| `/api/v3/hiu/consent/request/notify` | Gateway -> HIU | Working |

### M3 — Data Request
| Endpoint | Direction | Status |
|---|---|---|
| `/data-flow/v3/health-information/request` | HIU -> Gateway | 403 |

> **Why are some endpoints returning 403?** These V3 endpoints have WSO2 API Gateway subscription issues in the sandbox. See [docs/KNOWN-ISSUES.md](docs/KNOWN-ISSUES.md) for details and workarounds.

## Features

- **Auto-authentication**: Pre-request script automatically refreshes tokens before they expire
- **Environment variables**: Switch between sandbox and production with one click
- **Dynamic variables**: Uses Postman's `{{$guid}}` and `{{$isoTimestamp}}` for unique request IDs
- **Auto-extraction**: Response tests automatically save transaction IDs, consent IDs, and tokens
- **Realistic payloads**: Every request includes a complete example body with documentation
- **Status annotations**: Each endpoint description clearly marks whether it's working or returning 403

## Documentation

| Document | Description |
|---|---|
| [Setup Guide](docs/SETUP.md) | Step-by-step import and configuration |
| [Authentication](docs/AUTHENTICATION.md) | How ABDM V3 auth works, token management |
| [Known Issues](docs/KNOWN-ISSUES.md) | Sandbox 403 errors, workarounds, architecture changes |

## Key V3 Changes from V0.5

1. **Synchronous Discovery**: V3 discovery is synchronous — your HIP must respond with care contexts in the HTTP response body (no more async callback pattern)
2. **New URL Patterns**: V3 uses different URL prefixes (`user-initiated-linking/v3/`, `consent/v3/`, `data-flow/v3/`, `patient-share/v3/`)
3. **Simplified Auth**: Single session endpoint at `/gateway/v3/sessions`
4. **WSO2 Gateway**: Some endpoints are still being migrated in the sandbox

## Further Reading

- [ABDM Integration Milestones M1-M2-M3-M4: Multi-Software Guide](https://nirmitee.io/blog/abdm-integration-milestones-m1-m2-m3-m4-multi-software-guide/)
- [ABDM Certification Process: Sandbox to Production Guide](https://nirmitee.io/blog/abdm-certification-process-sandbox-to-production-guide)
- [ABDM Integration Troubleshooting: 25 Common Errors & Fixes](https://nirmitee.io/blog/abdm-integration-troubleshooting-25-common-errors-fixes)
- [ABDM V3 API Migration Guide: Everything That Changed](https://nirmitee.io/blog/abdm-v3-api-migration-guide-everything-that-changed)

## Contributing

Contributions are welcome! If you find new V3 endpoints, corrections, or workarounds:

1. Fork this repository
2. Create a feature branch (`git checkout -b feature/add-new-endpoint`)
3. Add or update the endpoint in the relevant collection JSON
4. Update the status table in this README
5. Submit a pull request

Please ensure all Postman collection JSON files are valid and importable before submitting.

## License

MIT License. See [LICENSE](LICENSE) for details.

---

Maintained by [Nirmitee.io](https://nirmitee.io) — Building healthcare integrations that work.
