# FHIR Bundle Debugging for ABDM

When ABDM rejects your FHIR bundle, the error messages can be cryptic. This guide walks through a systematic approach to finding and fixing bundle issues.

---

## Step 1: Validate Your JSON

Before anything else, ensure your bundle is valid JSON. A surprising number of FHIR errors come from malformed JSON.

```bash
# Quick JSON validation
cat your-bundle.json | python3 -m json.tool > /dev/null

# If it prints nothing, JSON is valid
# If it prints an error, fix the JSON syntax first
```

Common JSON issues:
- Trailing commas after the last element in an array or object
- Unescaped special characters in strings
- Missing closing brackets
- Single quotes instead of double quotes

---

## Step 2: Validate Against FHIR R4

Use the HL7 FHIR Validator to check structural compliance:

```bash
# Download the validator (one-time)
curl -L -o validator_cli.jar \
  https://github.com/hapifhir/org.hl7.fhir.core/releases/latest/download/validator_cli.jar

# Run validation
java -jar validator_cli.jar your-bundle.json -version 4.0.1
```

This catches:
- Missing required fields
- Wrong data types
- Invalid code values
- Reference integrity issues

---

## Step 3: Validate Against NRCES (India-Specific) Profiles

ABDM uses NRCES profiles which add India-specific constraints on top of base FHIR R4:

```bash
java -jar validator_cli.jar your-bundle.json \
  -version 4.0.1 \
  -ig https://nrces.in/ndhm/fhir/r4/ImplementationGuide/ndhm.nrces
```

NRCES profiles enforce:
- Indian coding systems (ICD-10, SNOMED CT, LOINC)
- ABHA identifier format in Patient resource
- Specific resource profiles per health information type

---

## Step 4: Check Bundle Structure

ABDM requires a specific document bundle structure. Verify these rules:

### Rule 1: Bundle.type Must Be "document"

```json
{
  "resourceType": "Bundle",
  "type": "document",   // NOT "collection", NOT "transaction"
  ...
}
```

### Rule 2: First Entry Must Be Composition

```json
{
  "entry": [
    {
      "fullUrl": "urn:uuid:composition-01",
      "resource": {
        "resourceType": "Composition",  // MUST be first
        ...
      }
    },
    ...
  ]
}
```

### Rule 3: Every Resource Has a fullUrl

```json
{
  "entry": [
    {
      "fullUrl": "urn:uuid:some-unique-id",  // Required for every entry
      "resource": { ... }
    }
  ]
}
```

### Rule 4: Bundle Has Timestamp and Meta

```json
{
  "resourceType": "Bundle",
  "id": "urn:uuid:bundle-unique-id",
  "type": "document",
  "timestamp": "2026-03-18T10:00:00.000Z",
  "meta": {
    "lastUpdated": "2026-03-18T10:00:00.000Z"
  },
  "entry": [ ... ]
}
```

---

## Step 5: Verify Reference Integrity

Every `reference` field must point to an existing `fullUrl` in the bundle.

### Quick Reference Check Script

```python
import json
import sys

def check_references(bundle_path):
    with open(bundle_path) as f:
        bundle = json.load(f)

    # Collect all fullUrls
    full_urls = set()
    for entry in bundle.get("entry", []):
        if "fullUrl" in entry:
            full_urls.add(entry["fullUrl"])

    # Find all references
    def find_references(obj, path=""):
        refs = []
        if isinstance(obj, dict):
            if "reference" in obj and isinstance(obj["reference"], str):
                refs.append((path, obj["reference"]))
            for key, value in obj.items():
                refs.extend(find_references(value, f"{path}.{key}"))
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                refs.extend(find_references(item, f"{path}[{i}]"))
        return refs

    references = find_references(bundle)

    # Check each reference
    broken = []
    for path, ref in references:
        if ref.startswith("urn:uuid:") and ref not in full_urls:
            broken.append((path, ref))

    if broken:
        print(f"BROKEN REFERENCES ({len(broken)}):")
        for path, ref in broken:
            print(f"  {path} -> {ref}")
    else:
        print("All references valid.")

check_references(sys.argv[1])
```

```bash
python3 check_refs.py your-bundle.json
```

---

## Step 6: Check hiType-Specific Requirements

Different health information types have different minimum resource requirements:

### OPConsultation Bundle (Minimum)
```json
{
  "type": "document",
  "entry": [
    { "resource": { "resourceType": "Composition", "type": { "coding": [{ "code": "371530004", "system": "http://snomed.info/sct" }] } } },
    { "resource": { "resourceType": "Patient" } },
    { "resource": { "resourceType": "Encounter" } },
    { "resource": { "resourceType": "Practitioner" } }
  ]
}
```

### Prescription Bundle (Minimum)
```json
{
  "entry": [
    { "resource": { "resourceType": "Composition" } },
    { "resource": { "resourceType": "Patient" } },
    { "resource": { "resourceType": "MedicationRequest" } },
    { "resource": { "resourceType": "Practitioner" } }
  ]
}
```

### DiagnosticReport Bundle (Minimum)
```json
{
  "entry": [
    { "resource": { "resourceType": "Composition" } },
    { "resource": { "resourceType": "Patient" } },
    { "resource": { "resourceType": "DiagnosticReport" } },
    { "resource": { "resourceType": "Observation" } }
  ]
}
```

---

## Step 7: Validate Patient Resource

ABDM requires specific identifiers in the Patient resource:

```json
{
  "resourceType": "Patient",
  "identifier": [
    {
      "type": {
        "coding": [
          {
            "system": "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code": "MR"
          }
        ]
      },
      "system": "https://your-hospital.com/patients",
      "value": "PAT-12345"
    },
    {
      "type": {
        "coding": [
          {
            "system": "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code": "SN"
          }
        ]
      },
      "system": "https://healthid.abdm.gov.in",
      "value": "91-2345-6789-0123"
    }
  ],
  "name": [
    {
      "text": "John Doe",
      "family": "Doe",
      "given": ["John"]
    }
  ],
  "gender": "male"
}
```

Key checks:
- Patient must have at least one identifier
- ABHA number identifier uses system `https://healthid.abdm.gov.in`
- Name must include at least `text` field
- Gender must be one of: `male`, `female`, `other`, `unknown`

---

## Common Pitfalls

### 1. Date Format
```
WRONG:  "date": "18-03-2026"
WRONG:  "date": "03/18/2026"
RIGHT:  "date": "2026-03-18"
RIGHT:  "date": "2026-03-18T10:00:00.000Z"
```

### 2. Coding System URLs
```
WRONG:  "system": "snomed"
RIGHT:  "system": "http://snomed.info/sct"

WRONG:  "system": "loinc"
RIGHT:  "system": "http://loinc.org"

WRONG:  "system": "icd10"
RIGHT:  "system": "http://hl7.org/fhir/sid/icd-10"
```

### 3. Bundle ID Uniqueness
Generate a new UUID for every bundle. Never hardcode IDs.

### 4. Resource Status
Composition status must be `final` (not `preliminary`, not `draft`) for data sharing.

---

## Related

- [FHIR-1001: Invalid Bundle](../errors/fhir-validation-errors.md#fhir-1001--invalid-bundle)
- [FHIR-1002: Missing Required Resource](../errors/fhir-validation-errors.md#fhir-1002--missing-required-resource)
- [FHIR-1003: Duplicate Bundle Identifier](../errors/fhir-validation-errors.md#fhir-1003--duplicate-bundle-identifier)
- [FHIR-1004: Broken Resource Reference](../errors/fhir-validation-errors.md#fhir-1004--broken-resource-reference)
