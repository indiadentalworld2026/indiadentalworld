# Consent & Data Flow Errors

These errors occur during consent management and health data transfer workflows. Consent is a critical part of ABDM — patients must grant explicit consent before any health data can be shared between providers.

---

### CONSENT-1001 — Consent Artefact Expired

**Error Response:**
```json
{
  "code": "CONSENT-1001",
  "message": "Consent Artefact Expired",
  "details": {
    "consentId": "c3f0a8d2-...",
    "expiryDate": "2026-03-15T00:00:00.000Z"
  }
}
```

**What causes this:**

The consent artefact you're using has passed its `permission.dateRange.to` date. Consent artefacts are time-bound — once expired, they cannot be used to fetch data.

**How to fix it:**

1. Check the consent artefact's `permission.dateRange.to` field to confirm expiry.
2. Request a new consent from the patient via the consent request workflow.
3. When creating new consents, set a reasonable `dateRange` — not too short (causes this error frequently) and not too long (security concern).
4. Implement consent expiry monitoring: alert your system before consents expire if you need ongoing data access.

```json
{
  "permission": {
    "dateRange": {
      "from": "2020-01-01T00:00:00.000Z",
      "to": "2027-01-01T00:00:00.000Z"
    },
    "dataEraseAt": "2027-06-01T00:00:00.000Z"
  }
}
```

**Important:** Even if the consent hasn't expired, the `accessMode` (VIEW vs STORE vs QUERY) and `frequency` limits also apply. A consent can be valid by date but exhausted by usage.

---

### CONSENT-1002 — Consent Revoked

**Error Response:**
```json
{
  "code": "CONSENT-1002",
  "message": "Consent Revoked",
  "details": {
    "consentId": "c3f0a8d2-...",
    "revokedAt": "2026-03-17T14:30:00.000Z"
  }
}
```

**What causes this:**

The patient has explicitly revoked this consent artefact. Patients can revoke consent at any time via the ABHA app or PHR app.

**How to fix it:**

1. You **cannot** use a revoked consent. This is by design — patient autonomy is paramount.
2. Request a new consent from the patient if you still need data access.
3. If you had already fetched and stored data under this consent, check the `dataEraseAt` obligations.
4. Your system should handle consent revocation callbacks and update consent status in real-time.

**V3 callback for revocation:**
```json
// POST to your bridge URL: /v3/consent/hiu/notify
{
  "notification": {
    "status": "REVOKED",
    "consentArtefacts": [
      {
        "id": "c3f0a8d2-..."
      }
    ]
  }
}
```

---

### CONSENT-1003 — Invalid Consent Artefact

**Error Response:**
```json
{
  "code": "CONSENT-1003",
  "message": "Invalid Consent Artefact",
  "details": {
    "reason": "Signature verification failed"
  }
}
```

**What causes this:**

The consent artefact's digital signature could not be verified. This can happen if:
- The artefact was modified after signing
- The artefact was created in a different environment (sandbox vs production)
- A transmission error corrupted the artefact data
- You're using a stale/cached version of the artefact

**How to fix it:**

1. Re-fetch the consent artefact from the ABDM gateway using the consent ID.
2. Do not modify any field of a consent artefact after receiving it.
3. Ensure you're calling the correct environment (sandbox artefacts don't work in production).
4. If the issue persists after re-fetching, the artefact may be genuinely invalid — request a new consent.

---

### DATA-1001 — Data Push Failed

**Error Response:**
```json
{
  "code": "DATA-1001",
  "message": "Data Push Failed",
  "details": {
    "reason": "Failed to push health data to the data receiver",
    "transactionId": "tx-..."
  }
}
```

**What causes this:**

The HIP (Health Information Provider) failed to push encrypted health data to the HIU (Health Information User). Multiple things can go wrong:
- The `dataPushUrl` is unreachable
- Encryption is malformed (see DATA-1002)
- The FHIR bundle in the data payload is invalid
- The data payload exceeds size limits
- Network timeout during transfer

**How to fix it:**

1. **Verify `dataPushUrl` accessibility:** Ensure the HIU's data receiver URL is publicly reachable. Test with a simple HTTP GET.
2. **Check encryption:** Data must be encrypted using ECDH with Curve25519. See DATA-1002 for details.
3. **Validate the FHIR bundle:** Run it through a FHIR validator before encrypting. See [FHIR Bundle Debugging](../troubleshooting/fhir-bundle-debugging.md).
4. **Check payload size:** ABDM has undocumented size limits. Keep bundles under 5MB per transfer.
5. **Implement retry logic:** Data push is the most failure-prone operation. Retry up to 3 times with exponential backoff.

**Data push flow overview:**
```
HIU requests data → ABDM notifies HIP → HIP encrypts & pushes to dataPushUrl → HIU decrypts
```

---

### DATA-1002 — Invalid Encryption

**Error Response:**
```json
{
  "code": "DATA-1002",
  "message": "Invalid Encryption",
  "details": {
    "reason": "ECDH key exchange or AES encryption validation failed"
  }
}
```

**What causes this:**

The encryption on the health data payload is invalid. ABDM mandates specific encryption:
- **Key exchange:** ECDH using **Curve25519** (not P-256 or any other curve)
- **Encryption:** AES-256-GCM
- **Nonce:** Random, unique per encryption operation

Common mistakes:
- Using the wrong elliptic curve (P-256 instead of Curve25519)
- Reusing nonces across multiple encryption operations
- Incorrect key derivation from the ECDH shared secret
- Not using the receiver's public key correctly
- Encoding issues (Base64 vs raw bytes)

**How to fix it:**

1. **Use Curve25519**, not P-256:
   ```
   Key pair generation: X25519
   Key exchange: ECDH with X25519
   ```

2. **Generate a unique nonce** for every encryption operation:
   ```
   Nonce: 32 random bytes (not derived, not reused)
   ```

3. **Derive the AES key** correctly from the ECDH shared secret using HKDF.

4. **Encrypt with AES-256-GCM** using the derived key and nonce.

5. **Include in your response:**
   - Your ephemeral public key (so the receiver can derive the same shared secret)
   - The nonce used
   - The encrypted data

6. **Reference implementation:** See the [ABDM-wrapper encryption module](https://github.com/atulai-sg/abdm-wrapper) for a working example.

**Cross-reference:** If encryption is correct but data push still fails, see [DATA-1001](#data-1001--data-push-failed).
