# WSO2 / Gateway Errors

These errors originate from the WSO2 API gateway that sits in front of all ABDM APIs. They are infrastructure-level errors, not application logic errors.

> If you're getting a `403` with code `900908`, you almost certainly need V3 API access enabled. See the [full 403 fix guide](../troubleshooting/v3-403-fix.md).

---

### 900908 — API Subscription Validation Failed

**HTTP Status:** 403 Forbidden

**Error Response:**
```json
{
  "code": "900908",
  "message": "Resource forbidden",
  "description": "User is NOT authorized to access the Resource. API Subscription validation failed."
}
```

**What causes this:**

Your client ID (from sandbox registration) is not subscribed to the V3 API tier in WSO2. This is the single most common error when migrating from v0.5 to V3 APIs. Even if your client ID works perfectly for v0.5 endpoints, V3 requires a separate subscription that NHA must enable on their side.

**Affected endpoints (known to return 403 without V3 subscription):**
- All `/v3/hip/` endpoints (data-flow, linking)
- `/v3/hiu/` endpoints
- `/v3/patient-share/` endpoints
- Note: Some V3 endpoints like `/v3/hip/token/on-generate-token` may work before full subscription — this is inconsistent.

**How to fix it:**

1. Go to [devforum.abdm.gov.in](https://devforum.abdm.gov.in)
2. Create a new post in the integration support category
3. Tag `@IntegrationSupport` in the post
4. Include your **Client ID** (e.g., `SBXID_016837`) and request V3 API subscription
5. Wait 1-2 business days for NHA to process
6. Verify by calling any V3 endpoint — the 403 should be gone

**Full walkthrough:** [Fixing the V3 403 Error](../troubleshooting/v3-403-fix.md)

---

### 900901 — Invalid Credentials

**HTTP Status:** 401 Unauthorized

**Error Response:**
```json
{
  "code": "900901",
  "message": "Invalid Credentials",
  "description": "Access failure for API: /v3/hip/token/on-generate-token, version: v3. Make sure you have given the correct access token"
}
```

**What causes this:**

- Your access token has expired. ABDM gateway tokens have a **5-minute TTL**.
- The token is malformed (truncated, extra whitespace, wrong encoding).
- You're missing the `Bearer ` prefix in the Authorization header.
- You're using a sandbox token against production or vice versa.

**How to fix it:**

1. Always refresh your token immediately before making an API call if more than 4 minutes have passed since the last refresh.
2. Verify your Authorization header format: `Authorization: Bearer eyJhbGc...`
3. Ensure there's exactly one space between `Bearer` and the token.
4. Check you're using the correct environment (sandbox vs production).

```bash
# Get a fresh token
curl -X POST 'https://dev.abdm.gov.in/api/hiecm/gateway/v3/sessions' \
  -H 'Content-Type: application/json' \
  -d '{
    "clientId": "YOUR_CLIENT_ID",
    "clientSecret": "YOUR_CLIENT_SECRET"
  }'
```

**See also:** [Token Management Guide](../troubleshooting/token-management.md)

---

### 900902 — Missing Credentials

**HTTP Status:** 401 Unauthorized

**Error Response:**
```json
{
  "code": "900902",
  "message": "Missing Credentials",
  "description": "Required OAuth credentials not provided"
}
```

**What causes this:**

The `Authorization` header is completely missing from your request. Every ABDM API call (except `/sessions`) requires a Bearer token.

**How to fix it:**

Add the Authorization header to every request:

```bash
curl -X POST 'https://dev.abdm.gov.in/api/hiecm/gateway/v3/hip/token/on-generate-token' \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer YOUR_ACCESS_TOKEN' \
  -d '{ ... }'
```

Common causes:
- HTTP client library not forwarding headers on redirects
- Header name typo (e.g., `Authorisation` with an 's')
- Environment variable for the token is empty/unset

---

### 102500 — Unclassified Error

**HTTP Status:** 500 Internal Server Error

**Error Response:**
```json
{
  "code": "102500",
  "message": "Unclassified Error",
  "description": "An internal server error occurred"
}
```

**What causes this:**

This is a generic server-side error from the ABDM gateway. It means something went wrong on NHA's infrastructure, not in your request. Common triggers:
- Temporary service outage
- Database timeout on NHA's side
- Deployment or maintenance in progress

**How to fix it:**

1. **Wait 30 seconds** and retry the exact same request.
2. If it persists after 3 retries, wait 5 minutes and try again.
3. If it persists for more than 15 minutes, check the [ABDM Developer Forum](https://devforum.abdm.gov.in) for outage reports.
4. Post on devforum with the timestamp, endpoint, and your client ID so NHA can investigate.

**Important:** Do NOT change your request payload when you see this error. The issue is on the server side. Changing your request will make debugging harder.
