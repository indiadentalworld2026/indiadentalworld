-- Starting values. Everything marked 'placeholder' must be confirmed by your lawyer.
-- These are NOT legal advice; they are safe starting points that can be changed without a code change.

INSERT INTO settings (key, value, description) VALUES
  ('data_request_response_days', '30', 'Days we allow to answer a data export or deletion request'),
  ('grievance_response_days',    '15', 'Days we allow to answer a grievance'),
  ('verification_validity_days', '365', 'How long a "Verified" badge lasts before the registration is checked again'),
  ('max_sponsored_per_page',     '2',  'Most sponsored placements allowed on one results page');

-- Every revenue feature starts OFF and needs a named approver to be switched on.
INSERT INTO feature_flags (key, description) VALUES
  ('booking_commission',   'Take a percentage fee on bookings (needs counsel: fee-splitting rules)'),
  ('whatsapp_lead_fee',    'Charge per lead routed to a clinic (needs counsel: referral payment rules)'),
  ('sponsored_placements', 'Show labelled sponsored clinics on results pages (needs counsel: advertising rules)'),
  ('brand_partnerships',   'Show labelled partner content (needs counsel)');

-- Placeholder notice wording, version 1. Replace with the lawyer's approved text by adding version 2.
INSERT INTO notice_versions (purpose, version, body) VALUES
  ('privacy_notice',     1, '[PLACEHOLDER] Privacy notice text to be supplied by counsel.'),
  ('terms',              1, '[PLACEHOLDER] Terms of use text to be supplied by counsel.'),
  ('location',           1, '[PLACEHOLDER] We use your location only to show clinics near you.'),
  ('search_history',     1, '[PLACEHOLDER] We save your searches to help you find clinics again.'),
  ('marketing_email',    1, '[PLACEHOLDER] Send me updates by email.'),
  ('marketing_whatsapp', 1, '[PLACEHOLDER] Send me updates on WhatsApp.');
