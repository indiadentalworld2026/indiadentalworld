# ABDM V3 Error Code Catalog

**The definitive error reference for ABDM V3 API integration.**

No more guessing what `900908` means or why your data-flow endpoint returns `403`. Every known ABDM error code, documented with its cause and a concrete fix.

> Maintained by [Nirmitee.io](https://nirmitee.io) — Healthcare Integration Experts

---

## Most Common Errors

These are the five errors developers hit most frequently. If you're here in a hurry, start with these.

| Error Code | What It Means | One-Line Fix |
|------------|--------------|--------------|
| `900908` | V3 API subscription not enabled for your client ID | Post on [devforum.abdm.gov.in](https://devforum.abdm.gov.in) tagging `@IntegrationSupport` to request V3 access. [Full guide](troubleshooting/v3-403-fix.md) |
| `900901` | Access token expired or malformed | Refresh your token before every call. ABDM tokens expire in **5 minutes**. [Details](troubleshooting/token-management.md) |
| `ABDM-1017` | Transaction ID timed out or was reused | Generate a fresh transaction ID. ABHA transactions expire in 10 minutes. |
| `FHIR-1003` | Duplicate FHIR Bundle identifier | Use a new UUID (`urn:uuid:{{uuid}}`) for every bundle submission. |
| `BRIDGE-1002` | ABDM could not reach your callback URL | Ensure your URL is publicly accessible. Use `cloudflared` or `ngrok` for local dev. [Guide](troubleshooting/callback-debugging.md) |

---

## Quick Search Table

Find your error code, get the fix.

### WSO2 / Gateway Errors

| Code | HTTP | Message | Fix |
|------|------|---------|-----|
| `900908` | 403 | API Subscription validation failed | Request V3 API access via devforum. [Full guide](troubleshooting/v3-403-fix.md) |
| `900901` | 401 | Invalid Credentials | Refresh token (5-min TTL). Ensure `Bearer ` prefix. |
| `900902` | 401 | Missing Credentials | Add `Authorization: Bearer {{token}}` header. |
| `102500` | 500 | Unclassified Error | Retry after 30s. If persistent, raise on devforum. |

[Full details: Gateway Errors](errors/gateway-errors.md)

### ABDM Application Errors

| Code | Message | Fix |
|------|---------|-----|
| `ABDM-1017` | Invalid/Expired Transaction | Generate new transaction. 10-min expiry. |
| `ABDM-1018` | OTP Expired | Request new OTP. 10-min validity. |
| `ABDM-1019` | Invalid OTP | Re-enter OTP. Max 3 attempts before lockout. |
| `ABDM-1109` | Invalid Request | Validate JSON against API spec. |
| `ABDM-1100` | ABHA Number Not Found | Verify 14-digit format. Confirm patient has ABHA. |
| `ABDM-1101` | ABHA Address Not Found | Check format: `username@abdm`. |
| `ABDM-1115` | Aadhaar Already Linked | One Aadhaar = one ABHA. Use existing. |
| `ABDM-1116` | Mobile Number Mismatch | Must match Aadhaar-linked mobile. |

[Full details: Application Errors](errors/abdm-application-errors.md)

### Consent & Data Flow Errors

| Code | Message | Fix |
|------|---------|-----|
| `CONSENT-1001` | Consent Artefact Expired | Request new consent. Check `dateRange`. |
| `CONSENT-1002` | Consent Revoked | Request new consent from patient. |
| `CONSENT-1003` | Invalid Consent Artefact | Re-fetch artefact from gateway. |
| `DATA-1001` | Data Push Failed | Check encryption, `dataPushUrl`, FHIR validity. |
| `DATA-1002` | Invalid Encryption | Use Curve25519, verify nonce and key derivation. |

[Full details: Consent & Data Flow Errors](errors/consent-data-flow-errors.md)

### FHIR Validation Errors

| Code | Message | Fix |
|------|---------|-----|
| `FHIR-1001` | Invalid Bundle | Validate against NRCES profiles. |
| `FHIR-1002` | Missing Required Resource | Check hiType minimum resources. |
| `FHIR-1003` | Duplicate Bundle Identifier | Use `urn:uuid:{{new-uuid}}` per bundle. |
| `FHIR-1004` | Broken Resource Reference | Match all references to `fullUrl` entries. |

[Full details: FHIR Validation Errors](errors/fhir-validation-errors.md)

### Discovery & Linking Errors

| Code | Message | Fix |
|------|---------|-----|
| `LINK-1001` | Patient Not Found | Verify ABHA, check your system, configure fuzzy match. |
| `LINK-1002` | Care Context Already Linked | Check existing links before re-linking. |
| `LINK-1003` | Link Token Expired | Generate new token. 30-min expiry. |
| `LINK-1004` | Token Verification Failed | Retry. Known V3 issue with patient-share tokens. |

[Full details: Discovery & Linking Errors](errors/discovery-linking-errors.md)

### Bridge & Infrastructure Errors

| Code | Message | Fix |
|------|---------|-----|
| `BRIDGE-1001` | Bridge URL Not Registered | Register via sandbox portal or `PATCH /gateway/v3/bridge/url`. |
| `BRIDGE-1002` | Callback Timeout | Make URL publicly accessible. Use tunnel for dev. |
| `BRIDGE-1003` | WAF Blocked | Use sandbox portal UI as workaround. |

[Full details: Bridge & Infrastructure Errors](errors/bridge-infrastructure-errors.md)

### HTTP Status Codes in ABDM Context

| Status | Meaning |
|--------|---------|
| `200` | Success |
| `202` | Accepted — async processing started, check callback for result |
| `400` | Bad request — malformed JSON or missing fields |
| `401` | Unauthorized — token expired or missing `Bearer` prefix |
| `403` | Forbidden — V3 subscription not enabled or wrong base URL |
| `404` | Not found — check `v0.5` vs `V3` endpoint path |
| `500` | ABDM server error — retry or raise on devforum |

[Full details: HTTP Status Codes](errors/http-status-codes.md)

### CORS Errors (Client-Side)

| Error | Fix |
|-------|-----|
| `CORS policy: No 'Access-Control-Allow-Origin'` | ABDM APIs must be called from your **backend server**, not the browser. Use a server-side proxy. |

---

## Troubleshooting Guides

Step-by-step guides for the most painful integration problems:

- **[Fixing the V3 403 Error](troubleshooting/v3-403-fix.md)** — The #1 developer pain point. Full walkthrough.
- **[Token Management](troubleshooting/token-management.md)** — How to handle ABDM's 5-minute token TTL without losing your mind.
- **[FHIR Bundle Debugging](troubleshooting/fhir-bundle-debugging.md)** — Validate, fix, and submit correct FHIR bundles.
- **[Callback URL Debugging](troubleshooting/callback-debugging.md)** — Make your local server reachable by ABDM.

---

## Related Resources

- [ABDM Integration Troubleshooting: 25 Common Errors & Fixes](https://nirmitee.io/blog/abdm-integration-troubleshooting-25-common-errors-fixes)
- [ABDM V3 API Migration Guide: Everything That Changed](https://nirmitee.io/blog/abdm-v3-api-migration-guide-everything-that-changed)
- [ABDM Certification Process: Sandbox to Production Guide](https://nirmitee.io/blog/abdm-certification-process-sandbox-to-production-guide)
- [ABDM Official Developer Forum](https://devforum.abdm.gov.in)
- [NHA FAQ (March 2025)](https://abdm.gov.in/faq)
- [ABDM Sandbox Portal](https://sandbox.abdm.gov.in)

---

## Contributing

Found an error code not listed here? Have a better fix for an existing one? Contributions are welcome.

See [CONTRIBUTING.md](CONTRIBUTING.md) for how to submit new error codes via pull request.

---

## License

[MIT](LICENSE)
