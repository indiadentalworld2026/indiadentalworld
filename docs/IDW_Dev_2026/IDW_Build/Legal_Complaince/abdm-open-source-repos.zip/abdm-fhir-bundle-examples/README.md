# ABDM FHIR Bundle Examples

Production-ready FHIR R4 bundle examples for ABDM M2 (Milestone 2) health data transfer. Copy, customize, and push — no guesswork needed.

These are the exact JSON structures your HIP (Health Information Provider) needs to send when ABDM requests patient health records via the data-transfer flow.

## Supported hiTypes

| hiType | File | Resources | Description |
|--------|------|-----------|-------------|
| OPConsultation | [`bundles/op-consultation.json`](bundles/op-consultation.json) | 14 | Outpatient visit with vitals, diagnosis, prescriptions, procedure |
| Prescription | [`bundles/prescription.json`](bundles/prescription.json) | 12 | 4-drug prescription with dosage, frequency, dispense details |
| DiagnosticReport | [`bundles/diagnostic-report.json`](bundles/diagnostic-report.json) | 13 | Complete Blood Count (CBC) with 6 lab observations |
| DischargeSummary | [`bundles/discharge-summary.json`](bundles/discharge-summary.json) | 13 | Post-STEMI discharge with PCI procedure, medications, follow-up plan |
| ImmunizationRecord | [`bundles/immunization-record.json`](bundles/immunization-record.json) | 6 | Pediatric immunization — Hep B + Pentavalent vaccine |
| WellnessRecord | [`bundles/wellness-record.json`](bundles/wellness-record.json) | 11 | Vital signs (BP, HR, SpO2, temp) + body measurements (height, weight, BMI) |

## How to Use

### 1. Copy the bundle you need

```bash
cp bundles/op-consultation.json my-bundle.json
```

### 2. Replace sample data

Update these fields with real patient/provider data:

- **Patient**: name, ABHA number (`identifier[].value` where system is `https://healthid.ndhm.gov.in`), gender, DOB, address
- **Practitioner**: name, medical license number
- **Organization**: facility name, HFR ID (the `identifier[].value` where system is `https://facility.ndhm.gov.in`)
- **Bundle.identifier.value**: Generate a new UUID (`uuidgen` on macOS/Linux)
- **Bundle.timestamp**: Set to current ISO 8601 timestamp with IST offset (`+05:30`)
- **Clinical data**: Update diagnoses, medications, observations, etc. to match the actual patient record

### 3. Encrypt and push via ABDM API

```
1. Base64-encode the FHIR bundle JSON
2. Encrypt using the HIU's public key (from consent artifact)
3. Push via POST /v0.5/health-information/hip/on-request (v0.5)
   or the V3 data-transfer equivalent
```

Refer to the [ABDM sandbox documentation](https://sandbox.abdm.gov.in/docs/) for encryption and API details.

## Validation

### Quick JSON validation

```bash
# Validate JSON syntax for all bundles
./scripts/validate.sh
```

### FHIR profile validation

Download the [HL7 FHIR Validator](https://github.com/hapifhir/org.hl7.fhir.core/releases/latest) and run:

```bash
java -jar validator_cli.jar bundles/op-consultation.json \
  -version 4.0.1 \
  -ig https://nrces.in/ndhm/fhir/r4/package.tgz
```

> **Note**: The NRCES IG package may not always be available at that URL. Check [nrces.in/ndhm/fhir/r4](https://nrces.in/ndhm/fhir/r4/) for the latest package download link.

### Common validation errors

See [`docs/COMMON-ERRORS.md`](docs/COMMON-ERRORS.md) for the most frequent FHIR bundle errors that cause ABDM data-transfer rejection.

## Coding Systems

All bundles use standard healthcare coding systems. See [`docs/CODING-SYSTEMS.md`](docs/CODING-SYSTEMS.md) for a complete reference including:

- SNOMED CT codes commonly used in ABDM bundles
- LOINC codes for lab observations and vital signs
- ICD-10 codes for diagnoses
- NRCES profile URLs for each resource type

## ABDM Integration Context

These bundles are used during **M2 (Milestone 2)** of ABDM integration — the health data transfer flow:

1. **PHR app** sends a data request to ABDM gateway
2. **ABDM gateway** forwards the request to your HIP
3. **Your HIP** fetches the patient's records, wraps them in FHIR bundles (like the ones in this repo), encrypts them, and pushes them to the HIU

For a complete guide to ABDM milestones M1 through M4:
- [ABDM Integration Milestones M1-M4: Multi-Software Guide](https://nirmitee.io/blog/abdm-integration-milestones-m1-m2-m3-m4-multi-software-guide/)

For troubleshooting integration issues:
- [ABDM Integration Troubleshooting: 25 Common Errors & Fixes](https://nirmitee.io/blog/abdm-integration-troubleshooting-25-common-errors-fixes)

For V3 API migration:
- [ABDM V3 API Migration Guide: Everything That Changed](https://nirmitee.io/blog/abdm-v3-api-migration-guide-everything-that-changed)

## Project Structure

```
abdm-fhir-bundle-examples/
├── README.md                          # This file
├── LICENSE                            # MIT License
├── bundles/
│   ├── op-consultation.json           # OPConsultation hiType
│   ├── prescription.json              # Prescription hiType
│   ├── diagnostic-report.json         # DiagnosticReport hiType
│   ├── discharge-summary.json         # DischargeSummary hiType
│   ├── immunization-record.json       # ImmunizationRecord hiType
│   └── wellness-record.json           # WellnessRecord hiType
├── schemas/
│   └── bundle-validation-notes.md     # NRCES profile validation notes
├── scripts/
│   └── validate.sh                    # JSON syntax validation script
└── docs/
    ├── USAGE.md                       # Detailed usage guide
    ├── CODING-SYSTEMS.md              # SNOMED CT, LOINC, ICD-10 reference
    └── COMMON-ERRORS.md               # Common FHIR bundle rejection errors
```

## Contributing

Contributions are welcome. If you find an error in any bundle or want to add examples for additional clinical scenarios:

1. Fork this repository
2. Create a feature branch (`git checkout -b fix/platelet-loinc-code`)
3. Validate your changes (`./scripts/validate.sh`)
4. Submit a pull request with a clear description of the change

Please ensure:
- All JSON is valid and properly formatted (2-space indentation)
- Resource references are internally consistent
- SNOMED CT / LOINC / ICD-10 codes are accurate
- No real patient data is included

## Disclaimer

These bundles contain **fictional sample data** for development and testing purposes only. No real patient data or real ABHA numbers are included. Always validate bundles against the latest NRCES profiles before using in production.

## License

MIT License. See [LICENSE](LICENSE).

---

Maintained by [Nirmitee.io](https://nirmitee.io) — Healthcare Integration Experts
