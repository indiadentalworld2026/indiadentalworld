-- IDW compliance core: rules enforced inside the database.
-- The website and apps call these functions; they cannot skip the rules.

-- ================================================================ helpers
CREATE FUNCTION setting_int(p_key text) RETURNS integer
LANGUAGE sql STABLE AS $$ SELECT value::integer FROM settings WHERE key = p_key $$;

CREATE FUNCTION user_has_role(p_user uuid, p_roles user_role[]) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (SELECT 1 FROM users WHERE id = p_user AND status = 'active' AND role = ANY (p_roles))
$$;

CREATE FUNCTION forbid_change() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION '% on % is not allowed: this table is append-only', TG_OP, TG_TABLE_NAME
    USING ERRCODE = 'integrity_constraint_violation';
END $$;

-- ================================================================ audit log
CREATE FUNCTION audit_hash(p_prev text, p_at timestamptz, p_actor uuid, p_action text,
                           p_etype text, p_eid text, p_details jsonb) RETURNS text
LANGUAGE sql IMMUTABLE AS $$
  SELECT encode(digest(
    p_prev || '|' || to_char(p_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US') || '|' ||
    coalesce(p_actor::text, '') || '|' || p_action || '|' || p_etype || '|' || p_eid || '|' || p_details::text,
    'sha256'), 'hex')
$$;

CREATE FUNCTION log_audit(p_actor uuid, p_action text, p_etype text, p_eid text, p_details jsonb DEFAULT '{}')
RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE v_prev text; v_at timestamptz := clock_timestamp(); v_id bigint;
BEGIN
  PERFORM pg_advisory_xact_lock(7001);   -- one writer at a time keeps the chain in order
  SELECT hash INTO v_prev FROM audit_log ORDER BY id DESC LIMIT 1;
  v_prev := coalesce(v_prev, 'GENESIS');
  -- keep microsecond precision so the stored value reproduces the hash exactly
  v_at := date_trunc('microseconds', v_at);
  INSERT INTO audit_log (at, actor_user_id, action, entity_type, entity_id, details, prev_hash, hash)
  VALUES (v_at, p_actor, p_action, p_etype, p_eid, p_details, v_prev,
          audit_hash(v_prev, v_at, p_actor, p_action, p_etype, p_eid, p_details))
  RETURNING id INTO v_id;
  RETURN v_id;
END $$;

-- Returns no rows if the chain is intact; otherwise the first broken entry.
CREATE FUNCTION verify_audit_chain() RETURNS TABLE (broken_at bigint, reason text)
LANGUAGE plpgsql AS $$
DECLARE r record; v_prev text := 'GENESIS';
BEGIN
  FOR r IN SELECT * FROM audit_log ORDER BY id LOOP
    IF r.prev_hash <> v_prev THEN
      broken_at := r.id; reason := 'previous hash does not match'; RETURN NEXT; RETURN;
    END IF;
    IF r.hash <> audit_hash(r.prev_hash, r.at, r.actor_user_id, r.action, r.entity_type, r.entity_id, r.details) THEN
      broken_at := r.id; reason := 'entry content does not match its hash'; RETURN NEXT; RETURN;
    END IF;
    v_prev := r.hash;
  END LOOP;
END $$;

CREATE TRIGGER audit_no_update BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON audit_log FOR EACH STATEMENT EXECUTE FUNCTION forbid_change();
CREATE TRIGGER notice_no_update BEFORE UPDATE OR DELETE ON notice_versions FOR EACH ROW EXECUTE FUNCTION forbid_change();
CREATE TRIGGER consents_no_update BEFORE UPDATE OR DELETE ON consents FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- ================================================================ organisations
CREATE FUNCTION check_org_owner_role() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE v_role user_role; v_expected user_role;
BEGIN
  SELECT role INTO v_role FROM users WHERE id = NEW.owner_user_id;
  v_expected := CASE NEW.type
    WHEN 'clinic' THEN 'clinic_owner' WHEN 'lab' THEN 'lab_owner'
    WHEN 'vendor' THEN 'vendor_owner' WHEN 'institute' THEN 'institute_owner' END;
  IF v_role IS DISTINCT FROM v_expected THEN
    RAISE EXCEPTION 'a % must be owned by a user with role %, not %', NEW.type, v_expected, v_role;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER org_owner_role BEFORE INSERT OR UPDATE OF owner_user_id, type ON organisations
  FOR EACH ROW EXECUTE FUNCTION check_org_owner_role();

-- The verified badge is shown only for organisations in this view.
CREATE VIEW verified_organisations AS
  SELECT * FROM organisations WHERE verification_status = 'verified' AND verification_expires_at > now();

-- ================================================================ consent
CREATE VIEW current_consents AS
  SELECT DISTINCT ON (user_id, purpose) user_id, purpose, granted, notice_version_id, recorded_at
  FROM consents ORDER BY user_id, purpose, seq DESC;

CREATE FUNCTION has_consent(p_user uuid, p_purpose consent_purpose) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT coalesce((SELECT granted FROM current_consents WHERE user_id = p_user AND purpose = p_purpose), false)
$$;

-- Giving consent must reference the newest published wording for that purpose.
CREATE FUNCTION record_consent(p_user uuid, p_purpose consent_purpose, p_notice uuid,
                               p_granted boolean, p_source text) RETURNS uuid
LANGUAGE plpgsql AS $$
DECLARE v_id uuid; v_nv notice_versions; v_latest integer;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM users WHERE id = p_user AND status = 'active') THEN
    RAISE EXCEPTION 'consent can only be recorded for an active user';
  END IF;
  SELECT * INTO v_nv FROM notice_versions WHERE id = p_notice;
  IF NOT FOUND OR v_nv.purpose <> p_purpose THEN
    RAISE EXCEPTION 'notice version does not exist for purpose %', p_purpose;
  END IF;
  SELECT max(version) INTO v_latest FROM notice_versions WHERE purpose = p_purpose;
  IF p_granted AND v_nv.version <> v_latest THEN
    RAISE EXCEPTION 'consent must be given against the latest notice (version %)', v_latest;
  END IF;
  INSERT INTO consents (user_id, purpose, notice_version_id, granted, source)
  VALUES (p_user, p_purpose, p_notice, p_granted, p_source) RETURNING id INTO v_id;
  PERFORM log_audit(p_user, CASE WHEN p_granted THEN 'consent.granted' ELSE 'consent.withdrawn' END,
                    'user', p_user::text,
                    jsonb_build_object('purpose', p_purpose, 'notice_version', v_nv.version, 'source', p_source));
  RETURN v_id;
END $$;

-- Withdrawing is a single call, as easy as giving. Returns false if nothing was granted.
CREATE FUNCTION withdraw_consent(p_user uuid, p_purpose consent_purpose, p_source text DEFAULT 'web')
RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE v_notice uuid;
BEGIN
  IF NOT has_consent(p_user, p_purpose) THEN RETURN false; END IF;
  SELECT notice_version_id INTO v_notice FROM current_consents WHERE user_id = p_user AND purpose = p_purpose;
  PERFORM record_consent(p_user, p_purpose, v_notice, false, p_source);
  RETURN true;
END $$;

-- ================================================================ data rights
CREATE FUNCTION request_data_export(p_user uuid) RETURNS uuid
LANGUAGE plpgsql AS $$
DECLARE v_id uuid;
BEGIN
  INSERT INTO data_requests (user_id, kind, due_at)
  VALUES (p_user, 'export', now() + make_interval(days => setting_int('data_request_response_days')))
  RETURNING id INTO v_id;
  PERFORM log_audit(p_user, 'data_request.export_received', 'data_request', v_id::text);
  RETURN v_id;
END $$;

CREATE FUNCTION request_data_deletion(p_user uuid) RETURNS uuid
LANGUAGE plpgsql AS $$
DECLARE v_id uuid;
BEGIN
  SELECT id INTO v_id FROM data_requests
   WHERE user_id = p_user AND kind = 'delete' AND status IN ('received', 'in_progress');
  IF FOUND THEN RETURN v_id; END IF;           -- already requested: return the open request
  IF NOT EXISTS (SELECT 1 FROM users WHERE id = p_user AND status = 'active') THEN
    RAISE EXCEPTION 'only an active user can request deletion';
  END IF;
  INSERT INTO data_requests (user_id, kind, due_at)
  VALUES (p_user, 'delete', now() + make_interval(days => setting_int('data_request_response_days')))
  RETURNING id INTO v_id;
  UPDATE users SET status = 'deletion_pending' WHERE id = p_user;
  PERFORM log_audit(p_user, 'data_request.delete_received', 'data_request', v_id::text);
  RETURN v_id;
END $$;

CREATE FUNCTION export_user_data(p_user uuid) RETURNS jsonb
LANGUAGE sql STABLE AS $$
  SELECT jsonb_build_object(
    'profile',      (SELECT to_jsonb(u) - 'id' FROM users u WHERE u.id = p_user),
    'consents',     coalesce((SELECT jsonb_agg(jsonb_build_object('purpose', c.purpose, 'granted', c.granted,
                      'notice_version', n.version, 'source', c.source, 'recorded_at', c.recorded_at) ORDER BY c.recorded_at)
                      FROM consents c JOIN notice_versions n ON n.id = c.notice_version_id WHERE c.user_id = p_user), '[]'),
    'appointments', coalesce((SELECT jsonb_agg(to_jsonb(a) - 'patient_id' ORDER BY a.slot_at)
                      FROM appointments a WHERE a.patient_id = p_user), '[]'),
    'reviews',      coalesce((SELECT jsonb_agg(to_jsonb(r) - 'patient_id' ORDER BY r.created_at)
                      FROM reviews r WHERE r.patient_id = p_user), '[]'),
    'requests',     coalesce((SELECT jsonb_agg(to_jsonb(d) - 'user_id' ORDER BY d.received_at)
                      FROM data_requests d WHERE d.user_id = p_user), '[]'),
    'grievances',   coalesce((SELECT jsonb_agg(to_jsonb(g) - 'user_id' ORDER BY g.received_at)
                      FROM grievances g WHERE g.user_id = p_user), '[]')
  )
$$;

CREATE FUNCTION fulfil_data_export(p_request uuid, p_actor uuid) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE v_req data_requests; v_data jsonb;
BEGIN
  IF NOT user_has_role(p_actor, ARRAY['admin', 'grievance_officer']::user_role[]) THEN
    RAISE EXCEPTION 'only an admin or the grievance officer can fulfil data requests';
  END IF;
  SELECT * INTO v_req FROM data_requests WHERE id = p_request FOR UPDATE;
  IF NOT FOUND OR v_req.kind <> 'export' OR v_req.status = 'completed' THEN
    RAISE EXCEPTION 'not an open export request';
  END IF;
  v_data := export_user_data(v_req.user_id);
  UPDATE data_requests SET status = 'completed', completed_at = now() WHERE id = p_request;
  PERFORM log_audit(p_actor, 'data_request.export_completed', 'data_request', p_request::text);
  RETURN v_data;
END $$;

-- Reviews: the text of a review cannot be edited by anyone, except through
-- moderation (hide/show) or erasure on the patient's own request.
CREATE FUNCTION protect_review() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'reviews cannot be deleted';
  END IF;
  IF (NEW.rating, NEW.appointment_id, NEW.org_id, NEW.created_at) IS DISTINCT FROM
     (OLD.rating, OLD.appointment_id, OLD.org_id, OLD.created_at) THEN
    RAISE EXCEPTION 'a review cannot be changed after it is posted';
  END IF;
  IF NEW.body IS DISTINCT FROM OLD.body AND coalesce(current_setting('idw.erasing', true), '') <> 'on' THEN
    RAISE EXCEPTION 'review text cannot be edited';
  END IF;
  IF NEW.patient_id IS DISTINCT FROM OLD.patient_id AND coalesce(current_setting('idw.erasing', true), '') <> 'on' THEN
    RAISE EXCEPTION 'review author cannot be changed';
  END IF;
  IF NEW.moderation IS DISTINCT FROM OLD.moderation AND coalesce(current_setting('idw.moderating', true), '') <> 'on' THEN
    RAISE EXCEPTION 'reviews can only be hidden through moderation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER reviews_protect BEFORE UPDATE OR DELETE ON reviews FOR EACH ROW EXECUTE FUNCTION protect_review();

-- Erasure: personal details are removed; the audit trail, anonymous ratings and
-- consent history (proof that consent was given) are kept. LEGAL-PLACEHOLDER:
-- confirm with counsel what must be kept and for how long.
CREATE FUNCTION execute_data_deletion(p_request uuid, p_actor uuid) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE v_req data_requests; p consent_purpose;
BEGIN
  IF NOT user_has_role(p_actor, ARRAY['admin', 'grievance_officer']::user_role[]) THEN
    RAISE EXCEPTION 'only an admin or the grievance officer can execute deletion';
  END IF;
  SELECT * INTO v_req FROM data_requests WHERE id = p_request FOR UPDATE;
  IF NOT FOUND OR v_req.kind <> 'delete' THEN RAISE EXCEPTION 'not a deletion request'; END IF;
  IF v_req.status = 'completed' THEN RETURN; END IF;    -- safe to run twice
  IF EXISTS (SELECT 1 FROM organisations WHERE owner_user_id = v_req.user_id) THEN
    RAISE EXCEPTION 'user still owns an organisation: transfer or close it first';
  END IF;

  -- withdraw every consent still in force
  FOR p IN SELECT purpose FROM current_consents WHERE user_id = v_req.user_id AND granted LOOP
    INSERT INTO consents (user_id, purpose, notice_version_id, granted, source)
    SELECT v_req.user_id, p, notice_version_id, false, 'admin'
      FROM current_consents WHERE user_id = v_req.user_id AND purpose = p;
  END LOOP;

  PERFORM set_config('idw.erasing', 'on', true);
  UPDATE reviews SET body = '[removed at the author''s request]' WHERE patient_id = v_req.user_id;
  UPDATE grievances SET contact_name = 'removed', contact_info = 'removed', body = '[removed at the author''s request]'
   WHERE user_id = v_req.user_id AND status IN ('resolved', 'closed');
  UPDATE users SET phone = NULL, email = NULL, full_name = NULL, status = 'deleted', deleted_at = now()
   WHERE id = v_req.user_id;
  PERFORM set_config('idw.erasing', 'off', true);

  UPDATE data_requests SET status = 'completed', completed_at = now(),
         resolution_note = 'personal details removed' WHERE id = p_request;
  PERFORM log_audit(p_actor, 'data_request.delete_completed', 'data_request', p_request::text,
                    jsonb_build_object('user', v_req.user_id));
END $$;

-- ================================================================ grievances
CREATE FUNCTION submit_grievance(p_user uuid, p_name text, p_contact text, p_category text, p_body text)
RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE v_id uuid;
BEGIN
  INSERT INTO grievances (user_id, contact_name, contact_info, category, body, due_at)
  VALUES (p_user, p_name, p_contact, p_category, p_body,
          now() + make_interval(days => setting_int('grievance_response_days')))
  RETURNING id INTO v_id;
  PERFORM log_audit(p_user, 'grievance.received', 'grievance', v_id::text, jsonb_build_object('category', p_category));
  RETURN v_id;
END $$;

CREATE FUNCTION resolve_grievance(p_id uuid, p_officer uuid) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  IF NOT user_has_role(p_officer, ARRAY['grievance_officer', 'admin']::user_role[]) THEN
    RAISE EXCEPTION 'only the grievance officer or an admin can resolve grievances';
  END IF;
  UPDATE grievances SET status = 'resolved', resolved_at = now(), officer_id = p_officer
   WHERE id = p_id AND status IN ('received', 'in_progress');
  IF NOT FOUND THEN RAISE EXCEPTION 'grievance not found or already closed'; END IF;
  PERFORM log_audit(p_officer, 'grievance.resolved', 'grievance', p_id::text);
END $$;

-- ================================================================ verification queue
CREATE FUNCTION submit_verification(p_org uuid, p_user uuid, p_reg text, p_body text, p_doc text) RETURNS uuid
LANGUAGE plpgsql AS $$
DECLARE v_id uuid;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM organisations WHERE id = p_org AND owner_user_id = p_user) THEN
    RAISE EXCEPTION 'only the organisation owner can submit verification';
  END IF;
  IF EXISTS (SELECT 1 FROM verification_submissions WHERE org_id = p_org AND status IN ('submitted', 'in_review')) THEN
    RAISE EXCEPTION 'a verification request is already open for this organisation';
  END IF;
  INSERT INTO verification_submissions (org_id, submitted_by, registration_number, issuing_body, document_ref)
  VALUES (p_org, p_user, p_reg, p_body, p_doc) RETURNING id INTO v_id;
  UPDATE organisations SET verification_status = 'pending'
   WHERE id = p_org AND verification_status <> 'verified';
  PERFORM log_audit(p_user, 'verification.submitted', 'verification_submission', v_id::text,
                    jsonb_build_object('org', p_org));
  RETURN v_id;
END $$;

CREATE FUNCTION claim_verification(p_id uuid, p_reviewer uuid) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  IF NOT user_has_role(p_reviewer, ARRAY['verifier', 'admin']::user_role[]) THEN
    RAISE EXCEPTION 'only a verifier or admin can review verification requests';
  END IF;
  UPDATE verification_submissions SET status = 'in_review' WHERE id = p_id AND status = 'submitted';
  IF NOT FOUND THEN RAISE EXCEPTION 'request not found or not waiting for review'; END IF;
  PERFORM log_audit(p_reviewer, 'verification.review_started', 'verification_submission', p_id::text);
END $$;

-- Decide on a claimed request. The reviewer must not be the person who submitted it.
CREATE FUNCTION decide_verification(p_id uuid, p_reviewer uuid, p_approve boolean, p_reason text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE v verification_submissions;
BEGIN
  IF NOT user_has_role(p_reviewer, ARRAY['verifier', 'admin']::user_role[]) THEN
    RAISE EXCEPTION 'only a verifier or admin can decide verification requests';
  END IF;
  SELECT * INTO v FROM verification_submissions WHERE id = p_id FOR UPDATE;
  IF NOT FOUND OR v.status <> 'in_review' THEN RAISE EXCEPTION 'request is not in review'; END IF;
  IF v.submitted_by = p_reviewer THEN RAISE EXCEPTION 'you cannot decide your own verification request'; END IF;
  IF NOT p_approve AND coalesce(p_reason, '') = '' THEN RAISE EXCEPTION 'a rejection needs a reason'; END IF;

  UPDATE verification_submissions
     SET status = CASE WHEN p_approve THEN 'approved' ELSE 'rejected' END::submission_status,
         reviewed_by = p_reviewer, reviewed_at = now(), decision_reason = p_reason
   WHERE id = p_id;
  IF p_approve THEN
    UPDATE organisations SET verification_status = 'verified', verified_at = now(),
           verification_expires_at = now() + make_interval(days => setting_int('verification_validity_days'))
     WHERE id = v.org_id;
  ELSE
    UPDATE organisations SET verification_status = 'rejected' WHERE id = v.org_id AND verification_status <> 'verified';
  END IF;
  PERFORM log_audit(p_reviewer, CASE WHEN p_approve THEN 'verification.approved' ELSE 'verification.rejected' END,
                    'verification_submission', p_id::text, jsonb_build_object('org', v.org_id, 'reason', p_reason));
END $$;

-- Run daily: badges disappear when the registration check has expired.
CREATE FUNCTION expire_verifications() RETURNS integer
LANGUAGE plpgsql AS $$
DECLARE r record; n integer := 0;
BEGIN
  FOR r IN SELECT id FROM organisations WHERE verification_status = 'verified' AND verification_expires_at <= now() LOOP
    UPDATE organisations SET verification_status = 'expired' WHERE id = r.id;
    PERFORM log_audit(NULL, 'verification.expired', 'organisation', r.id::text);
    n := n + 1;
  END LOOP;
  RETURN n;
END $$;

-- Rows of a decided request are frozen.
CREATE FUNCTION freeze_decided_submission() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'verification requests cannot be deleted';
  END IF;
  IF OLD.status IN ('approved', 'rejected') THEN
    RAISE EXCEPTION 'a decided verification request cannot be changed; submit a new one';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER submission_freeze BEFORE UPDATE OR DELETE ON verification_submissions
  FOR EACH ROW EXECUTE FUNCTION freeze_decided_submission();

-- ================================================================ reviews
CREATE FUNCTION check_review_allowed() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE a appointments;
BEGIN
  SELECT * INTO a FROM appointments WHERE id = NEW.appointment_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'appointment not found'; END IF;
  IF a.status <> 'completed' THEN RAISE EXCEPTION 'a review needs a completed appointment'; END IF;
  IF a.patient_id <> NEW.patient_id OR a.org_id <> NEW.org_id THEN
    RAISE EXCEPTION 'review must be written by the patient of that appointment, for that clinic';
  END IF;
  IF NOT user_has_role(NEW.patient_id, ARRAY['patient']::user_role[]) THEN
    RAISE EXCEPTION 'only an active patient can post a review';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER review_allowed BEFORE INSERT ON reviews FOR EACH ROW EXECUTE FUNCTION check_review_allowed();

CREATE FUNCTION check_reply_allowed() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM reviews r JOIN organisations o ON o.id = r.org_id
                  WHERE r.id = NEW.review_id AND o.owner_user_id = NEW.author_id) THEN
    RAISE EXCEPTION 'only the owner of the reviewed organisation can reply';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER reply_allowed BEFORE INSERT ON review_replies FOR EACH ROW EXECUTE FUNCTION check_reply_allowed();

CREATE FUNCTION moderate_review(p_review uuid, p_actor uuid, p_hide boolean, p_reason text) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE v_rows integer;
BEGIN
  IF NOT user_has_role(p_actor, ARRAY['admin']::user_role[]) THEN
    RAISE EXCEPTION 'only an admin can moderate reviews';
  END IF;
  IF coalesce(p_reason, '') = '' THEN RAISE EXCEPTION 'moderation needs a recorded reason'; END IF;
  PERFORM set_config('idw.moderating', 'on', true);
  UPDATE reviews SET moderation = CASE WHEN p_hide THEN 'hidden' ELSE 'visible' END::moderation_status WHERE id = p_review;
  GET DIAGNOSTICS v_rows = ROW_COUNT;
  PERFORM set_config('idw.moderating', 'off', true);
  IF v_rows = 0 THEN RAISE EXCEPTION 'review not found'; END IF;
  PERFORM log_audit(p_actor, CASE WHEN p_hide THEN 'review.hidden' ELSE 'review.restored' END,
                    'review', p_review::text, jsonb_build_object('reason', p_reason));
END $$;

-- ================================================================ revenue guards
CREATE FUNCTION set_feature_flag(p_key text, p_enabled boolean, p_approved_by text, p_actor uuid) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  IF NOT user_has_role(p_actor, ARRAY['admin']::user_role[]) THEN
    RAISE EXCEPTION 'only an admin can change feature flags';
  END IF;
  UPDATE feature_flags
     SET enabled = p_enabled,
         approved_by = CASE WHEN p_enabled THEN p_approved_by ELSE approved_by END,
         approved_at = CASE WHEN p_enabled THEN now() ELSE approved_at END
   WHERE key = p_key;
  IF NOT FOUND THEN RAISE EXCEPTION 'unknown feature flag %', p_key; END IF;
  PERFORM log_audit(p_actor, 'feature_flag.' || CASE WHEN p_enabled THEN 'enabled' ELSE 'disabled' END,
                    'feature_flag', p_key, jsonb_build_object('approved_by', p_approved_by));
END $$;

CREATE FUNCTION check_sponsored_placement() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE v_count integer;
BEGIN
  IF NOT coalesce((SELECT enabled FROM feature_flags WHERE key = 'sponsored_placements'), false) THEN
    RAISE EXCEPTION 'sponsored placements are switched off until legal approval is recorded';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM verified_organisations WHERE id = NEW.org_id) THEN
    RAISE EXCEPTION 'only a currently verified organisation can be sponsored';
  END IF;
  PERFORM pg_advisory_xact_lock(hashtext(NEW.context));
  SELECT count(*) INTO v_count FROM sponsored_placements
   WHERE context = NEW.context AND tstzrange(starts_at, ends_at) && tstzrange(NEW.starts_at, NEW.ends_at);
  IF v_count >= setting_int('max_sponsored_per_page') THEN
    RAISE EXCEPTION 'at most % sponsored placements are allowed per results page', setting_int('max_sponsored_per_page');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER sponsored_check BEFORE INSERT ON sponsored_placements
  FOR EACH ROW EXECUTE FUNCTION check_sponsored_placement();
