#!/usr/bin/env bash
# validate.sh — Validate all FHIR bundle JSON files
# Usage: ./scripts/validate.sh
# Checks:
#   1. JSON syntax (via python3 json.tool or jq)
#   2. Required FHIR fields (resourceType, type, identifier, meta.profile, entry)
#   3. Internal reference consistency (all references resolve to a fullUrl)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE_DIR="${SCRIPT_DIR}/../bundles"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

PASS=0
FAIL=0
WARN=0

echo "============================================"
echo "  ABDM FHIR Bundle Validator"
echo "============================================"
echo ""

# Determine JSON parser
if command -v jq &>/dev/null; then
  JSON_TOOL="jq"
elif command -v python3 &>/dev/null; then
  JSON_TOOL="python3"
else
  echo -e "${RED}ERROR: Neither jq nor python3 found. Install one to validate JSON.${NC}"
  exit 1
fi

validate_json_syntax() {
  local file="$1"
  if [ "$JSON_TOOL" = "jq" ]; then
    jq empty "$file" 2>/dev/null
  else
    python3 -m json.tool "$file" > /dev/null 2>&1
  fi
}

validate_fhir_fields() {
  local file="$1"
  local basename
  basename="$(basename "$file")"
  local errors=0

  if [ "$JSON_TOOL" = "jq" ]; then
    # Check resourceType is Bundle
    local rt
    rt=$(jq -r '.resourceType // empty' "$file")
    if [ "$rt" != "Bundle" ]; then
      echo -e "  ${RED}FAIL${NC}: resourceType is '${rt}', expected 'Bundle'"
      errors=$((errors + 1))
    fi

    # Check type is document
    local btype
    btype=$(jq -r '.type // empty' "$file")
    if [ "$btype" != "document" ]; then
      echo -e "  ${RED}FAIL${NC}: Bundle.type is '${btype}', expected 'document'"
      errors=$((errors + 1))
    fi

    # Check identifier exists
    local ident
    ident=$(jq -r '.identifier.value // empty' "$file")
    if [ -z "$ident" ]; then
      echo -e "  ${RED}FAIL${NC}: Bundle.identifier.value is missing"
      errors=$((errors + 1))
    fi

    # Check meta.profile exists
    local profile_count
    profile_count=$(jq '.meta.profile | length' "$file" 2>/dev/null || echo 0)
    if [ "$profile_count" -eq 0 ]; then
      echo -e "  ${YELLOW}WARN${NC}: Bundle.meta.profile is missing"
      WARN=$((WARN + 1))
    fi

    # Check entry is non-empty
    local entry_count
    entry_count=$(jq '.entry | length' "$file" 2>/dev/null || echo 0)
    if [ "$entry_count" -eq 0 ]; then
      echo -e "  ${RED}FAIL${NC}: Bundle.entry is empty"
      errors=$((errors + 1))
    else
      echo -e "  Resources: ${entry_count}"
    fi

    # Check first entry is Composition
    local first_rt
    first_rt=$(jq -r '.entry[0].resource.resourceType // empty' "$file")
    if [ "$first_rt" != "Composition" ]; then
      echo -e "  ${RED}FAIL${NC}: First entry should be Composition, got '${first_rt}'"
      errors=$((errors + 1))
    fi

    # Check internal reference consistency
    local full_urls
    full_urls=$(jq -r '.entry[].fullUrl' "$file" 2>/dev/null)
    local references
    references=$(jq -r '.. | .reference? // empty' "$file" 2>/dev/null | sort -u)

    local broken=0
    while IFS= read -r ref; do
      [ -z "$ref" ] && continue
      if ! echo "$full_urls" | grep -qF "$ref"; then
        echo -e "  ${RED}FAIL${NC}: Broken reference: ${ref}"
        broken=$((broken + 1))
      fi
    done <<< "$references"

    if [ "$broken" -eq 0 ]; then
      echo -e "  ${GREEN}PASS${NC}: All internal references resolve"
    else
      errors=$((errors + broken))
    fi

    # Check patient has ABHA identifier
    local abha
    abha=$(jq -r '.entry[].resource | select(.resourceType == "Patient") | .identifier[] | select(.system == "https://healthid.ndhm.gov.in") | .value // empty' "$file" 2>/dev/null | head -1)
    if [ -z "$abha" ]; then
      echo -e "  ${YELLOW}WARN${NC}: Patient is missing ABHA number identifier"
      WARN=$((WARN + 1))
    else
      echo -e "  ABHA: ${abha}"
    fi
  else
    # Fallback: basic python3 checks
    python3 -c "
import json, sys
with open('${file}') as f:
    b = json.load(f)
errors = 0
if b.get('resourceType') != 'Bundle':
    print('  FAIL: resourceType is not Bundle'); errors += 1
if b.get('type') != 'document':
    print('  FAIL: type is not document'); errors += 1
if not b.get('identifier', {}).get('value'):
    print('  FAIL: identifier.value missing'); errors += 1
print(f'  Resources: {len(b.get(\"entry\", []))}')
sys.exit(errors)
" 2>/dev/null
    errors=$?
  fi

  return $errors
}

for bundle in "$BUNDLE_DIR"/*.json; do
  [ -f "$bundle" ] || continue
  basename="$(basename "$bundle")"
  echo "--- ${basename} ---"

  # Step 1: JSON syntax
  if validate_json_syntax "$bundle"; then
    echo -e "  ${GREEN}PASS${NC}: Valid JSON"
  else
    echo -e "  ${RED}FAIL${NC}: Invalid JSON syntax"
    FAIL=$((FAIL + 1))
    echo ""
    continue
  fi

  # Step 2: FHIR structure
  if validate_fhir_fields "$bundle"; then
    PASS=$((PASS + 1))
  else
    FAIL=$((FAIL + 1))
  fi

  echo ""
done

echo "============================================"
echo -e "  Results: ${GREEN}${PASS} passed${NC}, ${RED}${FAIL} failed${NC}, ${YELLOW}${WARN} warnings${NC}"
echo "============================================"

if [ "$FAIL" -gt 0 ]; then
  exit 1
fi
