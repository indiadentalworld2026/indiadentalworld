# ABDM Application Errors

These errors come from the ABDM application layer (not the gateway). They indicate problems with your request data, patient records, or business logic validation. Error codes use the `ABDM-xxxx` prefix.

---

### ABDM-1017 — Invalid/Expired Transaction

**Error Response:**
```json
{
  "code": "ABDM-1017",
  "message": "Invalid/Expired Transaction",
  "details": [
    {
      "message": "Transaction not found or expired",
      "code": "ABDM-1017",
      "attribute": "transactionId"
    }
  ]
}
```

**What causes this:**

- The `transactionId` has expired. ABHA transactions have a **10-minute** expiry window.
- The transaction ID was already consumed by a previous successful request.
- The transaction ID is from a different workflow (e.g., using a registration transaction ID in a verification call).
- Copy-paste error introduced whitespace or truncation in the transaction ID.

**How to fix it:**

1. Generate a fresh transaction by re-initiating the workflow (e.g., call the `/init` endpoint again).
2. Use the new `transactionId` immediately — do not cache it for later.
3. Complete the entire workflow (init -> verify OTP -> create) within 10 minutes.
4. Ensure you're using the transaction ID from the correct workflow step.

---

### ABDM-1018 — OTP Expired

**Error Response:**
```json
{
  "code": "ABDM-1018",
  "message": "OTP Expired",
  "details": [
    {
      "message": "The OTP has expired. Please request a new one.",
      "code": "ABDM-1018",
      "attribute": "otp"
    }
  ]
}
```

**What causes this:**

The OTP sent to the patient's mobile or email has exceeded its validity window. ABDM OTPs are valid for **10 minutes**.

**How to fix it:**

1. Call the OTP generation endpoint again to get a new OTP sent to the patient.
2. Ensure your UI prompts the patient immediately when the OTP arrives.
3. Add a countdown timer in your UI so patients know how much time they have.
4. Note: There may be rate limits on OTP generation. Avoid calling it in a tight loop.

---

### ABDM-1019 — Invalid OTP

**Error Response:**
```json
{
  "code": "ABDM-1019",
  "message": "Invalid OTP",
  "details": [
    {
      "message": "The OTP entered is incorrect",
      "code": "ABDM-1019",
      "attribute": "otp"
    }
  ]
}
```

**What causes this:**

The OTP value submitted does not match what was generated. This could be a typo, or the patient entered an OTP from a different session.

**How to fix it:**

1. Have the patient re-check and re-enter the OTP carefully.
2. Ensure you're sending the OTP as a string, not a number (leading zeros matter).
3. After **3 failed attempts**, the OTP is invalidated and the patient is temporarily locked out.
4. If locked out, wait a few minutes and generate a new OTP.
5. Verify you're submitting the OTP against the correct `transactionId`.

---

### ABDM-1109 — Invalid Request

**Error Response:**
```json
{
  "code": "ABDM-1109",
  "message": "Invalid Request",
  "details": [
    {
      "message": "Required field missing or invalid",
      "code": "ABDM-1109",
      "attribute": null
    }
  ]
}
```

**What causes this:**

Your request body is malformed or missing required fields. This is a catch-all validation error.

**How to fix it:**

1. Validate your JSON payload against the API specification on [ABDM Sandbox](https://sandbox.abdm.gov.in/docs/api).
2. Check for:
   - Missing required fields
   - Wrong data types (string vs number vs boolean)
   - Incorrect date formats (ABDM uses ISO 8601: `2026-03-18T10:30:00.000Z`)
   - Empty strings where values are required
   - Extra fields that aren't in the spec (some endpoints reject unknown fields)
3. Use a JSON validator to ensure your payload is valid JSON (no trailing commas, proper escaping).
4. Compare your request with the working examples in the sandbox documentation.

---

### ABDM-1100 — ABHA Number Not Found

**Error Response:**
```json
{
  "code": "ABDM-1100",
  "message": "ABHA Number Not Found",
  "details": [
    {
      "message": "No ABHA record found for the given number",
      "code": "ABDM-1100",
      "attribute": "ABHANumber"
    }
  ]
}
```

**What causes this:**

The ABHA number you provided does not exist in the ABDM system.

**How to fix it:**

1. Verify the ABHA number format: it must be exactly **14 digits** (e.g., `91-2345-6789-0123`).
2. Strip any formatting before sending — send `91234567890123`, not `91-2345-6789-0123`.
3. Confirm the patient actually has an ABHA number (not all patients do).
4. If in sandbox, ensure you're using a sandbox ABHA number, not a production one.
5. Double-check with the patient — they may have a different ABHA number than what's recorded.

---

### ABDM-1101 — ABHA Address Not Found

**Error Response:**
```json
{
  "code": "ABDM-1101",
  "message": "ABHA Address Not Found",
  "details": [
    {
      "message": "No record found for the given ABHA address",
      "code": "ABDM-1101",
      "attribute": "ABHAAddress"
    }
  ]
}
```

**What causes this:**

The ABHA address (PHR address) does not exist. An ABHA address is the patient's self-chosen identifier in the format `username@abdm`.

**How to fix it:**

1. Verify the format: `username@abdm` (always ends with `@abdm`).
2. The username is case-insensitive but must match exactly otherwise.
3. Confirm the patient has created an ABHA address (it's separate from the ABHA number).
4. Patients can have multiple ABHA addresses linked to one ABHA number — verify which one is active.

---

### ABDM-1115 — Aadhaar Already Linked

**Error Response:**
```json
{
  "code": "ABDM-1115",
  "message": "Aadhaar Already Linked",
  "details": [
    {
      "message": "This Aadhaar number is already linked to an existing ABHA",
      "code": "ABDM-1115",
      "attribute": "aadhaar"
    }
  ]
}
```

**What causes this:**

The patient's Aadhaar number is already linked to an existing ABHA. ABDM enforces **one Aadhaar = one ABHA**.

**How to fix it:**

1. The patient must use their existing ABHA account instead of creating a new one.
2. Help the patient recover their existing ABHA using the "Forgot ABHA" flow.
3. The patient can find their ABHA number via the ABHA mobile app or PHR app.
4. This is by design — do not attempt to bypass it. One person, one health ID.

---

### ABDM-1116 — Mobile Number Mismatch

**Error Response:**
```json
{
  "code": "ABDM-1116",
  "message": "Mobile Number Mismatch",
  "details": [
    {
      "message": "Mobile number does not match Aadhaar records",
      "code": "ABDM-1116",
      "attribute": "mobile"
    }
  ]
}
```

**What causes this:**

The mobile number provided during ABHA creation via Aadhaar does not match the mobile number linked to the patient's Aadhaar card at UIDAI.

**How to fix it:**

1. The patient must use the mobile number registered with their Aadhaar.
2. If the patient has changed their phone number since Aadhaar registration, they need to update it at a UIDAI center first.
3. Alternatively, use the **driving license** or **PAN-based** ABHA creation flow instead of Aadhaar, which allows any mobile number.
4. Note: ABDM cannot tell you what the correct mobile number is (privacy). The patient must know their Aadhaar-linked number.
