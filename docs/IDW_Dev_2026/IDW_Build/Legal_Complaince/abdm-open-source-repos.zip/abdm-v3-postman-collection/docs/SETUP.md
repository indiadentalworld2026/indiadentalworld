# Setup Guide

## Prerequisites

1. **Postman** (v10+ recommended) — [Download](https://www.postman.com/downloads/)
2. **ABDM Sandbox Account** — Register at [sandbox.abdm.gov.in](https://sandbox.abdm.gov.in)
3. **Bridge Registration** — Your HIP/HIU must be registered in the ABDM sandbox

## Step 1: Import the Collection

1. Open Postman
2. Click **Import** (top-left)
3. Drag and drop the collection JSON file from `collections/`
4. Choose **ABDM-V3-Complete.postman_collection.json** for all endpoints, or import individual module collections

## Step 2: Import the Environment

1. Click **Import** again
2. Select `environments/ABDM-V3-Sandbox.postman_environment.json`
3. After import, click the **Environments** tab in the left sidebar
4. Select **ABDM V3 — Sandbox**

## Step 3: Configure Your Credentials

Fill in these required environment variables:

| Variable | Where to Find It |
|---|---|
| `clientId` | Your SBXID from the ABDM sandbox portal |
| `clientSecret` | Secret generated when you registered your bridge |
| `hipId` | Your HIP facility ID (e.g., `IN2710004770`) |
| `hiuId` | Your HIU facility ID (same as HIP if registered as both) |
| `bridgeUrl` | Your publicly accessible callback URL (use cloudflared for local dev) |

## Step 4: Get Your Access Token

1. Select the **ABDM V3 — Sandbox** environment in the top-right dropdown
2. Open **Authentication > Get Access Token**
3. Click **Send**
4. The pre-request script will automatically save the token to `{{accessToken}}`

The token is valid for ~30 minutes. The collection's pre-request script auto-refreshes it when it expires.

## Step 5: Verify Your Setup

Run the **Bridge Management > Get Bridge Services** request. If you get a 200 response with your registered services, your setup is complete.

## Local Development with Cloudflared

For testing callback endpoints (discovery, linking, consent), ABDM needs to reach your local server. Use Cloudflare Tunnel:

```bash
# Install
brew install cloudflare/cloudflare/cloudflared

# Start tunnel (replace 3200 with your server port)
cloudflared tunnel --url http://localhost:3200
```

Copy the generated `*.trycloudflare.com` URL and set it as your `bridgeUrl` environment variable. Then update your bridge URL via the **Bridge Management > Update Bridge URL** request.

> **Note:** The bridge URL update via API may be blocked by CloudFront WAF in sandbox. If you get a 403, update it manually through the [ABDM Sandbox Portal](https://sandbox.abdm.gov.in) UI.

## Switching to Production

1. Import `environments/ABDM-V3-Production.postman_environment.json`
2. Fill in your production credentials
3. Select the **ABDM V3 — Production** environment from the dropdown
4. All URLs will automatically point to production endpoints

## Troubleshooting

- **401 Unauthorized**: Your token has expired. Re-run the auth request.
- **403 Forbidden**: Check if the endpoint is marked as "Known 403" in the request description. Some V3 endpoints have WSO2 subscription issues in sandbox.
- **404 Not Found**: Verify your base URLs match the environment (sandbox vs production).
- **Network Error**: Ensure your bridge URL is publicly accessible if testing callback endpoints.

For more troubleshooting help, see [ABDM Integration Troubleshooting: 25 Common Errors & Fixes](https://nirmitee.io/blog/abdm-integration-troubleshooting-25-common-errors-fixes).
