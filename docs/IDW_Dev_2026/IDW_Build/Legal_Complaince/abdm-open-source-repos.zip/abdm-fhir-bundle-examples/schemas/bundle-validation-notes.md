# Bundle Validation Notes

## NRCES Profiles Used

Each bundle in this repository references NRCES (National Resource Centre for EHR Standards) profiles via `meta.profile`. These profiles define the minimum required fields and constraints for ABDM compliance.

### Bundle-Level Profile

All bundles use:
```
https://nrces.in/ndhm/fhir/r4/StructureDefinition/DocumentBundle
```

### Composition Profiles (per hiType)

| hiType | Composition Profile |
|--------|-------------------|
| OPConsultation | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/OPConsultRecord` |
| Prescription | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/PrescriptionRecord` |
| DiagnosticReport | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/DiagnosticReportRecord` |
| DischargeSummary | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/DischargeSummaryRecord` |
| ImmunizationRecord | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/ImmunizationRecordComposition` |
| WellnessRecord | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/WellnessRecordComposition` |

### Resource-Level Profiles

| Resource | Profile URL |
|----------|------------|
| Patient | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/Patient` |
| Practitioner | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/Practitioner` |
| Organization | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/Organization` |
| Condition | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/Condition` |
| Observation (vitals) | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/ObservationVitalSigns` |
| Observation (general) | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/ObservationGeneralAssessment` |
| MedicationRequest | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/MedicationRequest` |
| Procedure | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/Procedure` |
| DiagnosticReport | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/DiagnosticReportLab` |
| DocumentReference | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/DocumentReference` |
| Immunization | `https://nrces.in/ndhm/fhir/r4/StructureDefinition/Immunization` |

## Validation Approach

### Level 1: JSON Syntax
Basic JSON parsing — catches missing commas, unmatched brackets, etc.

### Level 2: FHIR R4 Base Compliance
Validates against FHIR R4 base specification — correct resource types, required fields, valid data types.

### Level 3: NRCES Profile Compliance
Validates against NRCES India profiles — additional mandatory fields, specific coding requirements, cardinality constraints.

### Running Full Validation

```bash
# Download the FHIR validator JAR (one-time setup)
curl -L -o validator_cli.jar \
  https://github.com/hapifhir/org.hl7.fhir.core/releases/latest/download/validator_cli.jar

# Validate a single bundle
java -jar validator_cli.jar bundles/op-consultation.json \
  -version 4.0.1 \
  -ig https://nrces.in/ndhm/fhir/r4/package.tgz

# Validate all bundles
for f in bundles/*.json; do
  echo "=== $(basename $f) ==="
  java -jar validator_cli.jar "$f" -version 4.0.1
  echo ""
done
```

## Known Validation Notes

1. **NRCES IG availability**: The NRCES package URL may change. If validation fails to download the IG, download it manually from [nrces.in](https://nrces.in/ndhm/fhir/r4/).

2. **Informational warnings**: The FHIR validator may emit warnings about preferred vs. required bindings (e.g., condition category codes). These are informational and do not indicate ABDM rejection.

3. **Terminology server**: For full SNOMED CT / LOINC validation, you may need to configure a terminology server. Without one, the validator will skip terminology checks.
