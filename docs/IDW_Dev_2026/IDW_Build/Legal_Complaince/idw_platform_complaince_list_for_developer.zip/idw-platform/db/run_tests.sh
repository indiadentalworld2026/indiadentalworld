#!/usr/bin/env bash
# Builds a fresh test database, loads the schema, and runs the compliance tests.
# Usage: PGHOST=... PGPORT=... PGUSER=... ./run_tests.sh
set -euo pipefail
cd "$(dirname "$0")"
DB=idw_compliance_test
psql -v ON_ERROR_STOP=1 -d postgres -qc "DROP DATABASE IF EXISTS $DB;" -c "CREATE DATABASE $DB;"
for f in 001_schema.sql 002_functions.sql 003_seed.sql; do
  psql -v ON_ERROR_STOP=1 -d "$DB" -q -f "$f"
done
psql -d "$DB" -f tests/test_compliance.sql 2>&1 | grep -E "PASS|FAIL|ERROR|PASSED|wrong error|should have" || true
psql -d postgres -qc "DROP DATABASE $DB;"
