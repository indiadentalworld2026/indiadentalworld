# HTTP Status Codes in ABDM Context

Every HTTP status code from ABDM has a specific meaning in context. This guide maps status codes to their ABDM-specific interpretation and the action you should take.

---

### 200 — Success

**Meaning:** The request was processed successfully and the response body contains the result.

**When you see it:**
- Synchronous V3 endpoints (e.g., discovery, session creation)
- Successful token generation
- Bridge URL registration

**Action:** Parse the response body for the result data.

---

### 202 — Accepted

**Meaning:** The request was accepted for **asynchronous processing**. The actual result will arrive via a callback to your bridge URL.

**When you see it:**
- Consent request submission
- Data transfer initiation
- v0.5 async operations

**Action:**
1. Store the `requestId` from your request.
2. Wait for the callback at your bridge URL.
3. Match the incoming callback's `requestId` to your stored request.
4. **Do NOT assume success.** 202 means "I'll process this later" — the callback will contain the actual success or failure.

```json
// Your request gets 202
// Later, ABDM calls your bridge URL:
POST /v3/consent/hiu/on-notify
{
  "requestId": "your-original-request-id",
  "status": "SUCCESS",  // or "FAILURE"
  ...
}
```

**Common mistake:** Treating 202 as "done." It's not. You must implement the callback handler.

---

### 400 — Bad Request

**Meaning:** Your request body is malformed or missing required fields.

**Typical response:**
```json
{
  "error": {
    "code": "ABDM-1109",
    "message": "Invalid Request",
    "details": [
      {
        "message": "field 'purpose' is required",
        "attribute": "purpose"
      }
    ]
  }
}
```

**Common causes:**
- Missing required JSON fields
- Wrong data types (sending `"true"` string instead of `true` boolean)
- Invalid date format (use ISO 8601: `2026-03-18T10:30:00.000Z`)
- Malformed UUID values
- Trailing commas in JSON
- Incorrect `Content-Type` header (must be `application/json`)

**Action:**
1. Read the `details` array — it usually tells you exactly which field is wrong.
2. Validate your JSON against the API spec.
3. Test with a minimal valid payload first, then add fields incrementally.

---

### 401 — Unauthorized

**Meaning:** Your authentication is invalid or missing.

**Typical response:**
```json
{
  "code": "900901",
  "message": "Invalid Credentials",
  "description": "Access failure for API: /v3/hip/token/on-generate-token"
}
```

**Common causes:**
- Access token expired (ABDM tokens have a **5-minute TTL**)
- Missing `Bearer ` prefix in Authorization header
- Using a sandbox token against production (or vice versa)
- Token from a different client ID
- Extra whitespace or newlines in the token

**Action:**
1. Refresh your token: call `/v3/sessions` to get a new one.
2. Verify the Authorization header format: `Authorization: Bearer eyJhbGc...`
3. Check you're using the correct environment.

**See also:** [Token Management Guide](../troubleshooting/token-management.md)

---

### 403 — Forbidden

**Meaning:** You're authenticated but not authorized to access this resource.

**Typical response:**
```json
{
  "code": "900908",
  "message": "Resource forbidden",
  "description": "User is NOT authorized to access the Resource. API Subscription validation failed."
}
```

**Two distinct causes:**

1. **WSO2 subscription issue (code `900908`):** Your client ID is not subscribed to V3 APIs. This is the #1 developer problem. See [Full 403 Fix Guide](../troubleshooting/v3-403-fix.md).

2. **CloudFront WAF block (HTML response, no JSON code):** AWS WAF is blocking your request. See [BRIDGE-1003](bridge-infrastructure-errors.md#bridge-1003--waf-blocked).

**How to tell them apart:**
- JSON response with `"code": "900908"` → WSO2 subscription issue
- HTML response with "403 ERROR" and "Request blocked" → CloudFront WAF

**Action for 900908:**
1. Post on [devforum.abdm.gov.in](https://devforum.abdm.gov.in) tagging `@IntegrationSupport`
2. Request V3 API access for your client ID
3. Wait 1-2 business days

---

### 404 — Not Found

**Meaning:** The endpoint you're calling doesn't exist.

**Common causes:**
- Using a v0.5 endpoint path with V3 base URL (or vice versa)
- Typo in the endpoint path
- Using the wrong HTTP method (GET instead of POST)

**V0.5 vs V3 path differences:**
```
v0.5: /v0.5/care-contexts/discover
V3:   /v3/hip/patient/discover

v0.5: /v0.5/consents/hip/notify
V3:   /v3/consent/hip/notify

v0.5: /v0.5/links/link/init
V3:   /v3/hip/link/init
```

**Action:**
1. Verify you're using the correct API version path.
2. Check the [ABDM API documentation](https://sandbox.abdm.gov.in/docs/api) for the exact endpoint path.
3. Ensure your HTTP method matches (most ABDM endpoints are POST).

---

### 500 — Internal Server Error

**Meaning:** Something went wrong on ABDM's side.

**Typical response:**
```json
{
  "code": "102500",
  "message": "Unclassified Error",
  "description": "An internal server error occurred"
}
```

**Action:**
1. **Do NOT change your request.** The issue is on the server side.
2. Retry after 30 seconds.
3. If it persists after 3 retries, wait 5-10 minutes.
4. Check [devforum.abdm.gov.in](https://devforum.abdm.gov.in) for known outages.
5. If it persists for more than 30 minutes, post on devforum with:
   - Timestamp (IST)
   - Endpoint URL
   - Your client ID
   - Request ID (if available in the response)

---

## Status Code Decision Tree

```
Got an error?
├── 400 → Read the error details. Fix your request payload.
├── 401 → Refresh your token. Check Bearer prefix.
├── 403
│   ├── JSON with code 900908 → V3 subscription needed. Post on devforum.
│   └── HTML "403 ERROR" → CloudFront WAF. Use portal UI instead.
├── 404 → Check v0.5 vs V3 endpoint path. Verify HTTP method.
├── 500 → Retry after 30s. Not your fault.
└── 202 → Not an error! Wait for the callback at your bridge URL.
```
