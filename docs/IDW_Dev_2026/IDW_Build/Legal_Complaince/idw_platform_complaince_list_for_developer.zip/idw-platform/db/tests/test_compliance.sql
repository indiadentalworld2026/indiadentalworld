-- Compliance tests. Run through db/run_tests.sh. Everything runs in one transaction that is rolled back.
\set ON_ERROR_STOP on
\set QUIET on
SET client_min_messages = notice;
BEGIN;

CREATE FUNCTION pg_temp.expect_fail(p_sql text, p_frag text) RETURNS void LANGUAGE plpgsql AS $$
DECLARE v_ok boolean := false;
BEGIN
  BEGIN
    EXECUTE p_sql; v_ok := true;
  EXCEPTION WHEN OTHERS THEN
    IF position(lower(p_frag) IN lower(SQLERRM)) = 0 THEN
      RAISE EXCEPTION 'wrong error for [%]: got "%", wanted text containing "%"', p_sql, SQLERRM, p_frag;
    END IF;
  END;
  IF v_ok THEN RAISE EXCEPTION 'should have failed but succeeded: %', p_sql; END IF;
END $$;

CREATE FUNCTION pg_temp.check_that(p_ok boolean, p_name text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  IF p_ok IS NOT TRUE THEN RAISE EXCEPTION 'FAIL: %', p_name; END IF;
  RAISE NOTICE 'PASS: %', p_name;
END $$;

-- ------------------------------------------------------------ fixtures
INSERT INTO users (id, role, phone, email, full_name) VALUES
 ('00000000-0000-0000-0000-000000000001', 'patient',       '+910000000001', 'p1@example.com', 'Patient One'),
 ('00000000-0000-0000-0000-000000000002', 'patient',       '+910000000002', 'p2@example.com', 'Patient Two'),
 ('00000000-0000-0000-0000-000000000003', 'clinic_owner',  '+910000000003', 'c1@example.com', 'Clinic Owner'),
 ('00000000-0000-0000-0000-000000000004', 'clinic_owner',  '+910000000004', 'c2@example.com', 'Clinic Owner Two'),
 ('00000000-0000-0000-0000-000000000005', 'verifier',      '+910000000005', 'v@example.com',  'Verifier'),
 ('00000000-0000-0000-0000-000000000006', 'admin',         '+910000000006', 'a@example.com',  'Admin'),
 ('00000000-0000-0000-0000-000000000007', 'grievance_officer', '+910000000007', 'g@example.com', 'Officer'),
 ('00000000-0000-0000-0000-000000000008', 'lab_owner',     '+910000000008', 'l@example.com',  'Lab Owner');
INSERT INTO organisations (id, type, name, owner_user_id) VALUES
 ('10000000-0000-0000-0000-000000000001', 'clinic', 'Test Clinic One', '00000000-0000-0000-0000-000000000003'),
 ('10000000-0000-0000-0000-000000000002', 'clinic', 'Test Clinic Two', '00000000-0000-0000-0000-000000000004');

-- ------------------------------------------------------------ audit log
SELECT log_audit('00000000-0000-0000-0000-000000000006', 'test.event', 'test', '1', '{"a":1}');
SELECT log_audit(NULL, 'test.event2', 'test', '2');
SELECT pg_temp.check_that((SELECT count(*) FROM verify_audit_chain()) = 0, 'audit chain is intact after writes');
SELECT pg_temp.expect_fail($$UPDATE audit_log SET action = 'edited'$$, 'append-only');
SELECT pg_temp.expect_fail($$DELETE FROM audit_log$$, 'append-only');
SELECT pg_temp.expect_fail($$TRUNCATE audit_log$$, 'append-only');
SELECT pg_temp.check_that(true, 'audit log refuses update, delete and truncate');

ALTER TABLE audit_log DISABLE TRIGGER audit_no_update;
UPDATE audit_log SET details = '{"a":2}' WHERE action = 'test.event';
SELECT pg_temp.check_that((SELECT count(*) FROM verify_audit_chain()) = 1, 'tampering with an audit entry is detected');
UPDATE audit_log SET details = '{"a":1}' WHERE action = 'test.event';
ALTER TABLE audit_log ENABLE TRIGGER audit_no_update;
SELECT pg_temp.check_that((SELECT count(*) FROM verify_audit_chain()) = 0, 'chain verifies again once restored');

-- ------------------------------------------------------------ consent
SELECT pg_temp.expect_fail($$UPDATE notice_versions SET body = 'changed'$$, 'append-only');
SELECT pg_temp.check_that(true, 'published notice wording cannot be changed');

SELECT record_consent('00000000-0000-0000-0000-000000000001', 'location',
  (SELECT id FROM notice_versions WHERE purpose = 'location' AND version = 1), true, 'web');
SELECT pg_temp.check_that(has_consent('00000000-0000-0000-0000-000000000001', 'location'), 'consent can be given');
SELECT pg_temp.check_that(NOT has_consent('00000000-0000-0000-0000-000000000001', 'marketing_email'), 'no consent is assumed by default');
SELECT pg_temp.check_that(withdraw_consent('00000000-0000-0000-0000-000000000001', 'location'), 'withdrawal is one call');
SELECT pg_temp.check_that(NOT has_consent('00000000-0000-0000-0000-000000000001', 'location'), 'consent is off after withdrawal');
SELECT pg_temp.check_that(NOT withdraw_consent('00000000-0000-0000-0000-000000000001', 'location'), 'withdrawing twice does nothing');
SELECT pg_temp.check_that((SELECT count(*) FROM consents WHERE user_id = '00000000-0000-0000-0000-000000000001') = 2,
  'both the grant and the withdrawal are kept as history');
SELECT pg_temp.expect_fail($$UPDATE consents SET granted = true$$, 'append-only');
SELECT pg_temp.expect_fail($$DELETE FROM consents$$, 'append-only');
SELECT pg_temp.check_that(true, 'consent history cannot be edited or deleted');

SELECT pg_temp.expect_fail($$SELECT record_consent('00000000-0000-0000-0000-000000000001', 'marketing_email',
  (SELECT id FROM notice_versions WHERE purpose = 'location'), true, 'web')$$, 'notice version does not exist');
INSERT INTO notice_versions (purpose, version, body) VALUES ('location', 2, 'new wording');
SELECT pg_temp.expect_fail($$SELECT record_consent('00000000-0000-0000-0000-000000000001', 'location',
  (SELECT id FROM notice_versions WHERE purpose = 'location' AND version = 1), true, 'web')$$, 'latest notice');
SELECT pg_temp.check_that(true, 'consent must use the newest notice wording');
SELECT pg_temp.expect_fail($$SELECT record_consent('00000000-0000-0000-0000-000000000001', 'location',
  (SELECT id FROM notice_versions WHERE purpose = 'location' AND version = 2), true, 'fax')$$, 'check');
SELECT pg_temp.check_that(true, 'consent source must be a known channel');

-- ------------------------------------------------------------ appointments and reviews
INSERT INTO appointments (id, patient_id, org_id, slot_at, status) VALUES
 ('20000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', now() - interval '1 day', 'completed'),
 ('20000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', now() + interval '1 day', 'booked');
SELECT pg_temp.expect_fail($$INSERT INTO reviews (appointment_id, patient_id, org_id, rating, body) VALUES
 ('20000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001',5,'great')$$, 'completed appointment');
SELECT pg_temp.expect_fail($$INSERT INTO reviews (appointment_id, patient_id, org_id, rating, body) VALUES
 ('20000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','10000000-0000-0000-0000-000000000001',5,'great')$$, 'patient of that appointment');
INSERT INTO reviews (id, appointment_id, patient_id, org_id, rating, body) VALUES
 ('30000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001',4,'Good visit');
SELECT pg_temp.check_that(true, 'only a completed visit by that patient can be reviewed');
SELECT pg_temp.expect_fail($$INSERT INTO reviews (appointment_id, patient_id, org_id, rating, body) VALUES
 ('20000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001',5,'again')$$, 'unique');
SELECT pg_temp.check_that(true, 'one review per visit');
SELECT pg_temp.expect_fail($$UPDATE reviews SET body = 'edited by clinic'$$, 'cannot be edited');
SELECT pg_temp.expect_fail($$UPDATE reviews SET rating = 5$$, 'cannot be changed');
SELECT pg_temp.expect_fail($$DELETE FROM reviews$$, 'cannot be deleted');
SELECT pg_temp.expect_fail($$UPDATE reviews SET moderation = 'hidden'$$, 'moderation');
SELECT pg_temp.check_that(true, 'reviews cannot be edited, deleted or hidden directly');
SELECT pg_temp.expect_fail($$INSERT INTO review_replies (review_id, author_id, body) VALUES
 ('30000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000004','reply from another clinic')$$, 'only the owner');
INSERT INTO review_replies (review_id, author_id, body) VALUES
 ('30000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','Thank you');
SELECT pg_temp.check_that(true, 'only the reviewed clinic can reply');
SELECT pg_temp.expect_fail($$SELECT moderate_review('30000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003',true,'x')$$, 'only an admin');
SELECT pg_temp.expect_fail($$SELECT moderate_review('30000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000006',true,'')$$, 'recorded reason');
SELECT moderate_review('30000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000006',true,'abusive language');
SELECT pg_temp.check_that((SELECT moderation FROM reviews) = 'hidden', 'admin can hide a review with a recorded reason');
SELECT pg_temp.check_that((SELECT count(*) FROM audit_log WHERE action = 'review.hidden') = 1, 'moderation is written to the audit log');
SELECT pg_temp.expect_fail($$SELECT moderate_review('99999999-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000006',true,'x')$$, 'not found');
SELECT pg_temp.check_that(true, 'moderating a missing review fails clearly');

-- ------------------------------------------------------------ organisation owner roles
SELECT pg_temp.expect_fail($$INSERT INTO organisations (type, name, owner_user_id) VALUES
 ('lab','Wrong owner','00000000-0000-0000-0000-000000000003')$$, 'must be owned');
INSERT INTO organisations (type, name, owner_user_id) VALUES ('lab', 'Test Lab', '00000000-0000-0000-0000-000000000008');
SELECT pg_temp.check_that(true, 'an organisation must be owned by the matching kind of user');

-- ------------------------------------------------------------ verification queue
SELECT pg_temp.expect_fail($$SELECT submit_verification('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000004','KA-1','State Dental Council','doc1')$$, 'only the organisation owner');
SELECT submit_verification('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','KA-1','State Dental Council','doc1') AS sub1 \gset
SELECT pg_temp.check_that((SELECT verification_status FROM organisations WHERE id = '10000000-0000-0000-0000-000000000001') = 'pending', 'submitting moves the clinic to pending');
SELECT pg_temp.check_that(NOT EXISTS (SELECT 1 FROM verified_organisations WHERE id = '10000000-0000-0000-0000-000000000001'), 'no badge while pending');
SELECT pg_temp.expect_fail($$SELECT submit_verification('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000003','KA-1','State Dental Council','doc1b')$$, 'already open');
SELECT pg_temp.expect_fail(format($$SELECT decide_verification(%L,'00000000-0000-0000-0000-000000000005',true)$$, :'sub1'), 'not in review');
SELECT pg_temp.expect_fail(format($$SELECT claim_verification(%L,'00000000-0000-0000-0000-000000000001')$$, :'sub1'), 'only a verifier');
SELECT claim_verification(:'sub1'::uuid, '00000000-0000-0000-0000-000000000005');
SELECT pg_temp.expect_fail(format($$SELECT decide_verification(%L,'00000000-0000-0000-0000-000000000001',true)$$, :'sub1'), 'only a verifier');
SELECT pg_temp.expect_fail(format($$SELECT decide_verification(%L,'00000000-0000-0000-0000-000000000005',false,'')$$, :'sub1'), 'needs a reason');
SELECT decide_verification(:'sub1'::uuid, '00000000-0000-0000-0000-000000000005', true);
SELECT pg_temp.check_that(EXISTS (SELECT 1 FROM verified_organisations WHERE id = '10000000-0000-0000-0000-000000000001'), 'approval turns the badge on');
SELECT pg_temp.check_that((SELECT verification_expires_at > now() + interval '300 days' FROM organisations WHERE id = '10000000-0000-0000-0000-000000000001'), 'the badge has an expiry date');
SELECT pg_temp.expect_fail(format($$UPDATE verification_submissions SET status = 'rejected' WHERE id = %L$$, :'sub1'), 'cannot be changed');
SELECT pg_temp.expect_fail($$DELETE FROM verification_submissions$$, 'cannot be deleted');
SELECT pg_temp.check_that(true, 'a decided request is frozen');

-- the verifier cannot approve their own organisation
INSERT INTO users (id, role, phone) VALUES ('00000000-0000-0000-0000-000000000009', 'clinic_owner', '+910000000009');
INSERT INTO organisations (id, type, name, owner_user_id) VALUES ('10000000-0000-0000-0000-000000000003', 'clinic', 'Third Clinic', '00000000-0000-0000-0000-000000000009');
SELECT submit_verification('10000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000009','KA-3','State Dental Council','doc3') AS sub3 \gset
SELECT claim_verification(:'sub3'::uuid, '00000000-0000-0000-0000-000000000006');
SELECT decide_verification(:'sub3'::uuid, '00000000-0000-0000-0000-000000000006', false, 'registration number not found');
SELECT pg_temp.check_that((SELECT verification_status FROM organisations WHERE id = '10000000-0000-0000-0000-000000000003') = 'rejected', 'rejection with a reason marks the clinic rejected');
SELECT pg_temp.check_that(NOT EXISTS (SELECT 1 FROM verified_organisations WHERE id = '10000000-0000-0000-0000-000000000003'), 'rejected clinic has no badge');

-- self-approval blocked: a person who submitted a request cannot decide it, even if their role later changes
INSERT INTO users (id, role, phone) VALUES ('00000000-0000-0000-0000-000000000010', 'clinic_owner', '+910000000010');
INSERT INTO organisations (id, type, name, owner_user_id) VALUES ('10000000-0000-0000-0000-000000000004', 'clinic', 'Fourth Clinic', '00000000-0000-0000-0000-000000000010');
SELECT submit_verification('10000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000010','KA-4','State Dental Council','doc4') AS sub4 \gset
UPDATE users SET role = 'verifier' WHERE id = '00000000-0000-0000-0000-000000000010';   -- test setup: role changes after submitting
SELECT claim_verification(:'sub4'::uuid, '00000000-0000-0000-0000-000000000010');
SELECT pg_temp.expect_fail(format($$SELECT decide_verification(%L,'00000000-0000-0000-0000-000000000010',true)$$, :'sub4'), 'your own');
SELECT pg_temp.check_that((SELECT verification_status FROM organisations WHERE id = '10000000-0000-0000-0000-000000000004') = 'pending', 'nobody can approve their own verification request');

-- expiry removes the badge
UPDATE organisations SET verification_expires_at = now() - interval '1 day' WHERE id = '10000000-0000-0000-0000-000000000001';
SELECT pg_temp.check_that(NOT EXISTS (SELECT 1 FROM verified_organisations WHERE id = '10000000-0000-0000-0000-000000000001'), 'an expired badge disappears even before the daily job');
SELECT pg_temp.check_that(expire_verifications() = 1, 'the daily job marks it expired');
SELECT pg_temp.check_that((SELECT verification_status FROM organisations WHERE id = '10000000-0000-0000-0000-000000000001') = 'expired', 'status is expired');

-- ------------------------------------------------------------ revenue guards
-- make clinic one verified again for the placement tests
UPDATE organisations SET verification_status = 'verified', verified_at = now(), verification_expires_at = now() + interval '30 days'
 WHERE id = '10000000-0000-0000-0000-000000000001';
SELECT pg_temp.expect_fail($$INSERT INTO sponsored_placements (org_id, context, starts_at, ends_at) VALUES
 ('10000000-0000-0000-0000-000000000001','search:rct:blr', now(), now() + interval '7 days')$$, 'switched off');
SELECT pg_temp.check_that(true, 'sponsored placements are blocked while the flag is off');
SELECT pg_temp.expect_fail($$UPDATE feature_flags SET enabled = true WHERE key = 'sponsored_placements'$$, 'enabled_needs_approval');
SELECT pg_temp.expect_fail($$SELECT set_feature_flag('sponsored_placements', true, 'Counsel', '00000000-0000-0000-0000-000000000001')$$, 'only an admin');
SELECT set_feature_flag('sponsored_placements', true, 'Counsel opinion dated 2026', '00000000-0000-0000-0000-000000000006');
SELECT pg_temp.check_that((SELECT enabled FROM feature_flags WHERE key = 'sponsored_placements'), 'an admin can enable a flag with a named approver');
SELECT pg_temp.check_that((SELECT count(*) FROM audit_log WHERE action = 'feature_flag.enabled') = 1, 'the change is audited');
SELECT pg_temp.check_that(NOT (SELECT enabled FROM feature_flags WHERE key = 'booking_commission'), 'booking commission stays off by default');

INSERT INTO sponsored_placements (org_id, context, starts_at, ends_at) VALUES
 ('10000000-0000-0000-0000-000000000001','search:rct:blr', now(), now() + interval '7 days');
SELECT pg_temp.expect_fail($$INSERT INTO sponsored_placements (org_id, context, label, starts_at, ends_at) VALUES
 ('10000000-0000-0000-0000-000000000001','search:rct:blr2','Ad', now(), now() + interval '7 days')$$, 'check');
SELECT pg_temp.check_that(true, 'a sponsored placement can only carry the label "Sponsored"');
SELECT pg_temp.expect_fail($$INSERT INTO sponsored_placements (org_id, context, starts_at, ends_at) VALUES
 ('10000000-0000-0000-0000-000000000003','search:rct:blr', now(), now() + interval '7 days')$$, 'verified');
SELECT pg_temp.check_that(true, 'only a verified clinic can be sponsored');
-- second placement fills the page; a third is refused
UPDATE organisations SET verification_status = 'verified', verified_at = now(), verification_expires_at = now() + interval '30 days'
 WHERE id = '10000000-0000-0000-0000-000000000002';
INSERT INTO sponsored_placements (org_id, context, starts_at, ends_at) VALUES
 ('10000000-0000-0000-0000-000000000002','search:rct:blr', now(), now() + interval '7 days');
SELECT pg_temp.expect_fail($$INSERT INTO sponsored_placements (org_id, context, starts_at, ends_at) VALUES
 ('10000000-0000-0000-0000-000000000001','search:rct:blr', now(), now() + interval '7 days')$$, 'at most 2');
SELECT pg_temp.check_that(true, 'no more than two sponsored placements per results page');

-- ------------------------------------------------------------ grievances
SELECT submit_grievance('00000000-0000-0000-0000-000000000002','Patient Two','p2@example.com','review','Please check this review') AS gid \gset
SELECT pg_temp.check_that((SELECT due_at > now() + interval '14 days' FROM grievances WHERE id = :'gid'), 'a grievance gets a response deadline');
SELECT pg_temp.expect_fail(format($$SELECT resolve_grievance(%L,'00000000-0000-0000-0000-000000000002')$$, :'gid'), 'only the grievance officer');
SELECT resolve_grievance(:'gid'::uuid, '00000000-0000-0000-0000-000000000007');
SELECT pg_temp.check_that((SELECT status FROM grievances WHERE id = :'gid') = 'resolved', 'the grievance officer can resolve it');

-- ------------------------------------------------------------ data rights
SELECT request_data_export('00000000-0000-0000-0000-000000000001') AS exp1 \gset
SELECT pg_temp.expect_fail(format($$SELECT fulfil_data_export(%L,'00000000-0000-0000-0000-000000000001')$$, :'exp1'), 'only an admin');
SELECT fulfil_data_export(:'exp1'::uuid, '00000000-0000-0000-0000-000000000006') AS exported \gset
SELECT pg_temp.check_that((:'exported'::jsonb -> 'profile' ->> 'email') = 'p1@example.com', 'export contains the profile');
SELECT pg_temp.check_that(jsonb_array_length(:'exported'::jsonb -> 'consents') = 2, 'export contains the consent history');
SELECT pg_temp.check_that(jsonb_array_length(:'exported'::jsonb -> 'reviews') = 1, 'export contains reviews');
SELECT pg_temp.check_that(NOT (:'exported'::jsonb ? 'id'), 'export does not leak internal ids at the top level');

-- deletion of a patient who has given consent, posted a review and filed a grievance
SELECT record_consent('00000000-0000-0000-0000-000000000001', 'marketing_email',
  (SELECT id FROM notice_versions WHERE purpose = 'marketing_email'), true, 'web');
SELECT request_data_deletion('00000000-0000-0000-0000-000000000001') AS del1 \gset
SELECT pg_temp.check_that((SELECT status FROM users WHERE id = '00000000-0000-0000-0000-000000000001') = 'deletion_pending', 'requesting deletion marks the account pending');
SELECT pg_temp.check_that(request_data_deletion('00000000-0000-0000-0000-000000000001') = :'del1'::uuid, 'asking twice returns the same open request');
SELECT pg_temp.check_that((SELECT due_at > now() + interval '29 days' FROM data_requests WHERE id = :'del1'), 'the request has a response deadline');
SELECT pg_temp.expect_fail(format($$SELECT execute_data_deletion(%L,'00000000-0000-0000-0000-000000000001')$$, :'del1'), 'only an admin');
SELECT execute_data_deletion(:'del1'::uuid, '00000000-0000-0000-0000-000000000006');
SELECT pg_temp.check_that((SELECT phone IS NULL AND email IS NULL AND full_name IS NULL AND status = 'deleted' FROM users WHERE id = '00000000-0000-0000-0000-000000000001'), 'name, phone and email are removed');
SELECT pg_temp.check_that((SELECT body FROM reviews) LIKE '[removed%', 'review text is removed');
SELECT pg_temp.check_that((SELECT rating FROM reviews) = 4, 'the anonymous star rating is kept');
SELECT pg_temp.check_that(NOT has_consent('00000000-0000-0000-0000-000000000001', 'marketing_email'), 'all consents are withdrawn');
SELECT pg_temp.check_that((SELECT count(*) FROM consents WHERE user_id = '00000000-0000-0000-0000-000000000001') >= 4, 'consent history is kept as proof');
SELECT pg_temp.check_that((SELECT status FROM data_requests WHERE id = :'del1') = 'completed', 'the request is marked completed');
SELECT pg_temp.check_that((SELECT count(*) FROM audit_log WHERE action = 'data_request.delete_completed') = 1, 'deletion is recorded in the audit log');
SELECT execute_data_deletion(:'del1'::uuid, '00000000-0000-0000-0000-000000000006');
SELECT pg_temp.check_that(true, 'running the deletion twice is safe');
-- the phone number is free to register again
INSERT INTO users (role, phone) VALUES ('patient', '+910000000001');
SELECT pg_temp.check_that(true, 'a deleted person can sign up again with the same number');
-- owners must hand over before deleting
SELECT request_data_deletion('00000000-0000-0000-0000-000000000003') AS del2 \gset
SELECT pg_temp.expect_fail(format($$SELECT execute_data_deletion(%L,'00000000-0000-0000-0000-000000000006')$$, :'del2'), 'still owns an organisation');
SELECT pg_temp.check_that(true, 'a clinic owner cannot be deleted while they still own a clinic');

SELECT pg_temp.check_that((SELECT count(*) FROM verify_audit_chain()) = 0, 'audit chain is still intact at the end');

ROLLBACK;
\echo ALL COMPLIANCE TESTS PASSED
