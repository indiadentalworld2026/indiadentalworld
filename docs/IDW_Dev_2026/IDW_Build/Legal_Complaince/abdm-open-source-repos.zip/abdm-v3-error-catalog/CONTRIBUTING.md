# Contributing to the ABDM V3 Error Code Catalog

Thank you for helping make ABDM integration less painful for every developer.

## How to Add a New Error Code

1. **Fork this repository** and create a branch: `git checkout -b add-error-XXXX`

2. **Find the right file** in `errors/`:
   - `gateway-errors.md` — WSO2 / API gateway errors (codes like `900xxx`, `102xxx`)
   - `abdm-application-errors.md` — ABDM application errors (codes like `ABDM-xxxx`)
   - `consent-data-flow-errors.md` — Consent and health data transfer errors
   - `fhir-validation-errors.md` — FHIR bundle and resource errors
   - `discovery-linking-errors.md` — Patient discovery and care context linking errors
   - `bridge-infrastructure-errors.md` — Bridge URL, callback, and infrastructure errors
   - `http-status-codes.md` — HTTP-level status code meanings

3. **Follow this format** for each error entry:

```markdown
### ERROR-CODE — Short Description

**HTTP Status:** 4xx / 5xx (if applicable)

**Error Response:**
\```json
{
  "code": "ERROR-CODE",
  "message": "Exact error message from ABDM"
}
\```

**What causes this:**
Clear explanation of why this error occurs.

**How to fix it:**
1. Step-by-step fix
2. With specific actions
3. Not vague "contact support"

**Related errors:** Link to related error codes if applicable.
```

4. **Update the Quick Search Table** in `README.md` with a one-line entry.

5. **Submit a pull request** with:
   - The error code in the PR title
   - Where you encountered it (sandbox, production, which endpoint)
   - Any JSON response examples you can share

## Quality Standards

Every error entry must include:

- **The exact error code and message** as returned by the ABDM API
- **A concrete cause** — not "something went wrong"
- **An actionable fix** — specific steps a developer can follow right now
- **JSON response example** when available

## What We're Looking For

- Error codes not yet documented
- Better fixes or workarounds for existing errors
- JSON response examples from real API calls
- Edge cases and version-specific behavior (v0.5 vs V3)
- Production-specific errors not seen in sandbox

## Reporting Issues

If you're hitting an error you can't figure out:

1. Open a GitHub Issue with the error code, full JSON response, and the endpoint you called
2. Include your ABDM environment (sandbox vs production) and API version (v0.5 vs V3)
3. The community or maintainers will help identify the cause

## Code of Conduct

Be helpful. Be specific. Remember that every developer hitting an undocumented error is losing hours of their life. Your contribution saves that time for everyone who comes after.
