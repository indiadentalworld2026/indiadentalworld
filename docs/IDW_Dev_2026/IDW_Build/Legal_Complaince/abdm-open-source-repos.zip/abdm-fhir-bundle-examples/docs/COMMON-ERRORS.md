# Common FHIR Bundle Errors

These are the most frequent errors that cause ABDM to reject FHIR bundles during M2 data transfer. Check your bundles against this list before pushing to production.

---

## 1. Missing Bundle.identifier

**Error**: ABDM gateway rejects bundles without a unique identifier.

**Wrong**:
```json
{
  "resourceType": "Bundle",
  "type": "document",
  "entry": [...]
}
```

**Correct**:
```json
{
  "resourceType": "Bundle",
  "identifier": {
    "system": "https://your-hospital.example.in/bundle-ids",
    "value": "bc3c6c57-2053-4d0e-a7cf-89c6b2f1a1d5"
  },
  "type": "document",
  "entry": [...]
}
```

**Fix**: Always include `Bundle.identifier` with a `system` URI and a unique UUID `value`.

---

## 2. Non-Unique Resource Identifiers

**Error**: Two resources in the same bundle have the same `fullUrl`.

**Wrong**:
```json
{
  "entry": [
    { "fullUrl": "urn:uuid:obs-01", "resource": { "resourceType": "Observation", "id": "obs-01" } },
    { "fullUrl": "urn:uuid:obs-01", "resource": { "resourceType": "Observation", "id": "obs-02" } }
  ]
}
```

**Fix**: Every `fullUrl` in a bundle must be unique. Use distinct UUIDs for each resource.

---

## 3. Broken Internal References

**Error**: A `reference` field points to a `fullUrl` that does not exist in the bundle.

**Wrong**:
```json
{
  "subject": { "reference": "urn:uuid:patient-01" }
}
```
...but no entry has `"fullUrl": "urn:uuid:patient-01"`.

**Fix**: Ensure every `reference` value matches exactly one `fullUrl` in the same bundle. Run `./scripts/validate.sh` to catch these.

---

## 4. Missing Mandatory Fields per NRCES Profiles

**Error**: NRCES profiles require fields beyond the base FHIR R4 spec.

Common missing fields:

| Resource | Missing Field | NRCES Requirement |
|----------|--------------|-------------------|
| Patient | `identifier` (ABHA) | At least one identifier with system `https://healthid.ndhm.gov.in` |
| Patient | `name` | At least one HumanName with `text` or `given` + `family` |
| Composition | `type` | Must include SNOMED CT code for the document type |
| Composition | `custodian` | Must reference an Organization |
| MedicationRequest | `requester` | Must reference the prescribing Practitioner |
| Observation | `category` | Must include observation category (vital-signs, laboratory, etc.) |
| Observation | `code` | Must use LOINC code |
| DiagnosticReport | `code` | Must use LOINC code |
| DiagnosticReport | `status` | Must be one of: registered, partial, preliminary, final |

**Fix**: Cross-reference your resources with the NRCES profile definitions and the example bundles in this repo.

---

## 5. Incorrect Coding System URIs

**Error**: Using wrong URIs for coding systems.

**Wrong URIs** (commonly seen):
```
"system": "http://snomed.info/sct/"          ← trailing slash
"system": "https://snomed.info/sct"          ← https instead of http
"system": "http://loinc.org/"                ← trailing slash
"system": "http://www.loinc.org"             ← www prefix
"system": "http://hl7.org/fhir/sid/icd10"   ← missing hyphen
"system": "urn:oid:2.16.840.1.113883.6.96"  ← OID instead of URI
```

**Correct URIs**:
```
http://snomed.info/sct
http://loinc.org
http://hl7.org/fhir/sid/icd-10
http://unitsofmeasure.org
http://terminology.hl7.org/CodeSystem/v3-ActCode
http://terminology.hl7.org/CodeSystem/observation-category
http://terminology.hl7.org/CodeSystem/condition-clinical
http://terminology.hl7.org/CodeSystem/condition-ver-status
http://terminology.hl7.org/CodeSystem/v2-0203
http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation
```

**Fix**: Copy URIs exactly. No trailing slashes, no scheme changes.

---

## 6. Timestamp Format Issues

**Error**: Timestamps that do not follow ISO 8601 or lack timezone offset.

**Wrong**:
```
"timestamp": "2026-03-15 10:30:00"          ← space instead of T
"timestamp": "2026-03-15T10:30:00"          ← missing timezone
"timestamp": "15-03-2026T10:30:00+05:30"    ← DD-MM-YYYY format
"timestamp": "2026-03-15T10:30:00Z"         ← UTC when IST intended
```

**Correct**:
```
"timestamp": "2026-03-15T10:30:00+05:30"
```

**Fix**: Always use `YYYY-MM-DDThh:mm:ss+05:30` format for Indian healthcare records.

---

## 7. First Entry Not Composition

**Error**: FHIR document bundles must have a Composition resource as the first entry.

**Wrong**:
```json
{
  "entry": [
    { "resource": { "resourceType": "Patient" } },
    { "resource": { "resourceType": "Composition" } }
  ]
}
```

**Fix**: The Composition resource must always be `entry[0]`.

---

## 8. Missing Bundle.type

**Error**: Bundle is missing the `type` field or has the wrong value.

For ABDM health records, the type must always be `"document"`:
```json
{
  "resourceType": "Bundle",
  "type": "document"
}
```

Do not use `collection`, `transaction`, or `searchset` for ABDM hiType bundles.

---

## 9. Mismatched Composition.section.entry References

**Error**: The Composition sections reference resources that are not included in the bundle entries.

Every resource referenced in `Composition.section[].entry[]` must exist as a top-level entry in the bundle.

**Fix**: After building your Composition sections, verify that every referenced resource is included in `Bundle.entry[]`.

---

## 10. Missing meta.profile on Bundle

**Error**: NRCES validation requires `meta.profile` to declare which profile the bundle conforms to.

```json
{
  "resourceType": "Bundle",
  "meta": {
    "profile": [
      "https://nrces.in/ndhm/fhir/r4/StructureDefinition/DocumentBundle"
    ]
  }
}
```

**Fix**: Include `meta.profile` on the Bundle and on resources where NRCES profiles are defined.

---

## 11. Patient Missing ABHA Identifier

**Error**: ABDM expects the patient to have an ABHA number as an identifier.

```json
{
  "resourceType": "Patient",
  "identifier": [
    {
      "type": {
        "coding": [
          {
            "system": "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code": "SB",
            "display": "Social Beneficiary Identifier"
          }
        ]
      },
      "system": "https://healthid.ndhm.gov.in",
      "value": "22-3456-7890-1234"
    }
  ]
}
```

**Fix**: Always include the ABHA number with system `https://healthid.ndhm.gov.in`.

---

## 12. Observation Missing valueQuantity Units

**Error**: Numeric observations without proper UCUM units.

**Wrong**:
```json
{
  "valueQuantity": {
    "value": 120
  }
}
```

**Correct**:
```json
{
  "valueQuantity": {
    "value": 120,
    "unit": "mmHg",
    "system": "http://unitsofmeasure.org",
    "code": "mm[Hg]"
  }
}
```

**Fix**: Always include `unit`, `system` (must be `http://unitsofmeasure.org`), and `code` (UCUM code).

---

## Validation Checklist

Before pushing any bundle to ABDM:

- [ ] JSON is valid (no syntax errors)
- [ ] `Bundle.type` is `"document"`
- [ ] `Bundle.identifier` has a unique UUID value
- [ ] `Bundle.timestamp` is ISO 8601 with timezone
- [ ] `Bundle.meta.profile` includes DocumentBundle profile
- [ ] First entry is a Composition resource
- [ ] All `reference` values resolve to a `fullUrl` in the bundle
- [ ] Patient has ABHA number identifier
- [ ] Organization has HFR facility ID
- [ ] All coding systems use correct URIs (no trailing slashes)
- [ ] All Observations have proper units with UCUM codes
- [ ] Composition sections reference only resources present in the bundle
