# Usage Guide

## Overview

These FHIR bundles are used during ABDM M2 (health data transfer). When ABDM requests health records for a patient, your HIP must:

1. Retrieve the patient's clinical data from your database
2. Map it into FHIR R4 bundles matching the requested hiTypes
3. Encrypt each bundle with the HIU's public key
4. Push the encrypted data to ABDM

This repo provides the FHIR bundle templates for step 2.

## Step-by-Step Guide

### 1. Identify the hiType

The ABDM data request (`/v0.5/health-information/hip/request` or V3 equivalent) includes a list of `hiTypes`. Each hiType maps to a specific bundle structure:

| ABDM hiType | Bundle File |
|-------------|-------------|
| `OPConsultation` | `bundles/op-consultation.json` |
| `Prescription` | `bundles/prescription.json` |
| `DiagnosticReport` | `bundles/diagnostic-report.json` |
| `DischargeSummary` | `bundles/discharge-summary.json` |
| `ImmunizationRecord` | `bundles/immunization-record.json` |
| `WellnessRecord` | `bundles/wellness-record.json` |

### 2. Map Your Data

For each clinical record matching the requested date range and hiType:

#### Patient Mapping
```json
{
  "identifier": [
    {
      "system": "https://your-hospital.example.in/patient-ids",
      "value": "YOUR-MRN-HERE"
    },
    {
      "system": "https://healthid.ndhm.gov.in",
      "value": "PATIENT-ABHA-NUMBER"
    }
  ],
  "name": [{"text": "Patient Full Name", "family": "LastName", "given": ["FirstName"]}],
  "gender": "male|female|other|unknown",
  "birthDate": "YYYY-MM-DD"
}
```

#### Organization Mapping
```json
{
  "identifier": [
    {
      "system": "https://facility.ndhm.gov.in",
      "value": "YOUR-HFR-FACILITY-ID"
    }
  ],
  "name": "Your Hospital Name"
}
```

#### Practitioner Mapping
```json
{
  "identifier": [
    {
      "system": "https://doctor.ndhm.gov.in",
      "value": "DOCTOR-HPR-ID"
    }
  ],
  "name": [{"text": "Dr. Full Name"}]
}
```

### 3. Generate Unique Identifiers

Each bundle needs:
- **Bundle.id**: A unique ID for this bundle instance
- **Bundle.identifier.value**: A UUID (e.g., `uuidgen` output)
- **Bundle.timestamp**: ISO 8601 timestamp with IST offset: `2026-03-15T10:30:00+05:30`

Each resource within the bundle needs:
- **fullUrl**: A unique URN (e.g., `urn:uuid:<uuid>`)
- **resource.id**: Matching the URN suffix

### 4. Ensure Reference Consistency

Every `reference` field must point to a valid `fullUrl` in the same bundle:

```json
{
  "fullUrl": "urn:uuid:patient-01",
  "resource": {
    "resourceType": "Patient",
    "id": "patient-01"
  }
}
```

```json
{
  "subject": {
    "reference": "urn:uuid:patient-01"
  }
}
```

### 5. Encrypt and Push

After creating the FHIR bundle JSON:

```python
import json
import base64

# 1. Serialize to JSON string
bundle_json = json.dumps(fhir_bundle)

# 2. Base64 encode
bundle_b64 = base64.b64encode(bundle_json.encode()).decode()

# 3. Encrypt with HIU's public key (from consent artifact)
#    Use the key material and nonce from the data request
#    ABDM uses ECDH + AES-GCM encryption

# 4. Push via ABDM API
# POST /v0.5/health-information/hip/on-request
```

Refer to the [ABDM encryption documentation](https://sandbox.abdm.gov.in/docs/) for detailed encryption steps.

## Multiple Records Per Request

If a patient has multiple records for the requested date range, create one bundle per record. For example, if a patient had 3 OPD visits, create 3 separate OPConsultation bundles.

The ABDM data push API accepts an array of encrypted entries — one entry per bundle.

## Testing with ABDM Sandbox

1. Register on the [ABDM sandbox](https://sandbox.abdm.gov.in/)
2. Get sandbox credentials (Client ID + Secret)
3. Register your callback URL (use `cloudflared` tunnel for local dev)
4. Complete M1 (discovery + linking) first
5. Then test M2 data transfer with these bundles

## Programmatic Bundle Generation

For production systems, do not hardcode bundles. Instead, build a mapping layer:

```
Your DB schema → FHIR resource mapper → Bundle assembler → JSON serializer
```

Use these example bundles as the **target output specification** for your mapper.
