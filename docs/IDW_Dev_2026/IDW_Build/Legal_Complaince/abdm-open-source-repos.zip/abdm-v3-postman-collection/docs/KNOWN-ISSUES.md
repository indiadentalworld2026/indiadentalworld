# Known Issues — ABDM V3 Sandbox (March 2026)

This document tracks known issues with ABDM V3 APIs in the sandbox environment, based on real integration testing by [Nirmitee.io](https://nirmitee.io).

## 403 Forbidden on Specific V3 Modules

**Affected endpoints:**

| Module | Endpoints | Status |
|---|---|---|
| **Data Flow** | `data-flow/v3/health-information/hip/on-request`, `data-flow/v3/health-information/notify`, `data-flow/v3/health-information/request` | 403 |
| **HIP-Initiated Linking** | `v3/token/generate-token`, `hip/v3/link/carecontext`, `hip/v3/link/context/notify`, `hip/v3/link/patient/links/sms/notify2` | 403 |
| **Profile Share** | `patient-share/v3/on-share` | 403 |

**Root cause:** WSO2 API Gateway subscription configuration. These V3 endpoints are not yet fully subscribed/published in the sandbox WSO2 gateway. The v0.5 equivalents of these APIs also return 403 for the same reason.

**Workaround:** None available at this time. Monitor the [ABDM sandbox announcements](https://sandbox.abdm.gov.in) for updates. For testing data flow, you can use the ABDM sandbox test harness if available.

**Last verified:** March 2026

## Bridge URL Update via API Returns 403

**Endpoint:** `PATCH /gateway/v3/bridge/url`

**Root cause:** CloudFront WAF blocks the PATCH request to the gateway URL update endpoint.

**Workaround:** Update your bridge URL through the [ABDM Sandbox Portal](https://sandbox.abdm.gov.in) web UI instead of the API. Navigate to your bridge settings and update the URL manually.

## V3 Discovery is Synchronous

Unlike V0.5 where discovery used an async callback pattern (gateway calls your HIP, you respond later via `/on-discover`), V3 discovery is **synchronous**. The gateway calls your HIP's discovery endpoint, and you must return the matched care contexts directly in the HTTP response body.

This is a significant architectural change. Your HIP server must:
1. Receive the discovery request
2. Search for matching patients in real-time
3. Return care contexts in the same HTTP response (within gateway timeout)

## Token Expiry Not Consistent

Access tokens are documented as valid for 1800 seconds (30 minutes), but in practice, tokens may expire slightly earlier. The collection's pre-request script refreshes tokens with a 60-second buffer to account for this.

## Consent Flow Requires Real ABHA

Testing the consent flow end-to-end in sandbox requires a valid test ABHA number. The sandbox provides test ABHA numbers — use the M1 ABHA creation endpoints or the sandbox portal to create one.

## Gateway Callback Timing

When the ABDM gateway calls your HIP/HIU callback endpoints, there can be a variable delay (1-30 seconds). If your integration tests have tight timeouts, increase them to at least 60 seconds for sandbox testing.

## Further Reading

- [ABDM V3 API Migration Guide: Everything That Changed](https://nirmitee.io/blog/abdm-v3-api-migration-guide-everything-that-changed)
- [ABDM Integration Troubleshooting: 25 Common Errors & Fixes](https://nirmitee.io/blog/abdm-integration-troubleshooting-25-common-errors-fixes)
- [ABDM Integration Milestones M1-M2-M3-M4 Guide](https://nirmitee.io/blog/abdm-integration-milestones-m1-m2-m3-m4-multi-software-guide/)
