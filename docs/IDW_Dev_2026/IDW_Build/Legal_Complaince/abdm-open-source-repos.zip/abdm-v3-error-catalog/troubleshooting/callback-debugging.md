# Callback URL Debugging

ABDM needs to reach your server to send discovery requests, consent notifications, and data transfer callbacks. If your callback URL is unreachable, nothing works. This guide covers how to make your local development server accessible to ABDM.

---

## The Problem

ABDM's gateway runs on AWS. When it needs to send a callback (e.g., "a patient wants to discover records at your HIP"), it makes an HTTP POST to your registered bridge URL.

If you're developing locally, `localhost:3200` is not reachable from the internet. You need a tunnel.

---

## Option 1: Cloudflared (Recommended)

[Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/) is free, fast, and doesn't require an account for quick tunnels.

### Setup

```bash
# Install (macOS)
brew install cloudflare/cloudflare/cloudflared

# Install (Linux)
curl -L --output cloudflared.deb https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared.deb

# Start tunnel
cloudflared tunnel --url http://localhost:3200
```

Output:
```
2026-03-18T10:00:00Z INF +--------------------------------------------------------------------------------------------+
2026-03-18T10:00:00Z INF |  Your quick Tunnel has been created! Visit it at (it may take some time to be reachable):  |
2026-03-18T10:00:00Z INF |  https://random-words-here.trycloudflare.com                                               |
2026-03-18T10:00:00Z INF +--------------------------------------------------------------------------------------------+
```

### Register with ABDM

Take the tunnel URL and register it as your bridge URL:

1. Go to [sandbox.abdm.gov.in](https://sandbox.abdm.gov.in)
2. Navigate to your facility settings
3. Set bridge URL to `https://random-words-here.trycloudflare.com`
4. Save

### Caveats
- The URL changes every time you restart `cloudflared`. You'll need to update your bridge URL each time.
- For a persistent URL, set up a named tunnel with a Cloudflare account (free tier).

---

## Option 2: ngrok

[ngrok](https://ngrok.com) is another popular option. Free tier gives you a persistent subdomain format.

```bash
# Install
brew install ngrok

# Authenticate (one-time, free account required)
ngrok config add-authtoken YOUR_AUTH_TOKEN

# Start tunnel
ngrok http 3200
```

Output:
```
Session Status: online
Forwarding: https://abcd1234.ngrok-free.app -> http://localhost:3200
```

Register `https://abcd1234.ngrok-free.app` as your bridge URL.

### Caveats
- Free tier URLs change on restart (unless you pay for a fixed subdomain).
- ngrok adds an interstitial page for free accounts — ABDM callbacks may be affected. Use `--host-header=rewrite` if needed.

---

## Verifying Your Callback URL

After setting up a tunnel and registering the URL, verify ABDM can reach you:

### Test 1: External Reachability

```bash
# From a different network or use an online tool
curl -v https://your-tunnel-url.trycloudflare.com/health
```

Expected: Your server's health check response. If you get a connection error, the tunnel is down.

### Test 2: Simulate an ABDM Callback

Send a test request that mimics what ABDM would send:

```bash
curl -X POST https://your-tunnel-url.trycloudflare.com/v3/hip/patient/on-discover \
  -H 'Content-Type: application/json' \
  -H 'X-CM-ID: sbx' \
  -d '{
    "requestId": "test-request-123",
    "timestamp": "2026-03-18T10:00:00.000Z",
    "patient": {
      "id": "test@abdm",
      "verifiedIdentifiers": [
        {
          "type": "HEALTH_NUMBER",
          "value": "91-2345-6789-0123"
        }
      ],
      "unverifiedIdentifiers": [],
      "name": "Test Patient",
      "gender": "M",
      "yearOfBirth": 1990
    }
  }'
```

Expected: Your server processes the discovery request and returns a response.

### Test 3: Check Server Logs

Watch your server logs while testing. You should see:
1. Incoming request from the tunnel
2. Your discovery/callback handler processing it
3. A response being sent back

```bash
# If using Node.js, add request logging
app.use((req, res, next) => {
  console.log(`${req.method} ${req.path} from ${req.ip}`);
  next();
});
```

---

## Common Issues

### Tunnel Is Up But ABDM Callbacks Don't Arrive

1. **Bridge URL not updated:** After starting a new tunnel, you must update the bridge URL in ABDM. The old URL won't work.

2. **Wrong port:** Ensure the tunnel points to the port your server is actually running on.
   ```bash
   # If your server runs on port 3200
   cloudflared tunnel --url http://localhost:3200

   # NOT port 3000 or 8080 unless that's where your server is
   ```

3. **Server not running:** The tunnel forwards traffic, but your server must be running to handle it.

4. **HTTPS redirect issues:** Some servers redirect HTTP to HTTPS. The tunnel already provides HTTPS, so your server should listen on plain HTTP.

### Callback Arrives But Returns Error

1. **Check endpoint paths:** ABDM expects specific paths:
   ```
   V3 Discovery: POST /v3/hip/patient/on-discover
   V3 Consent:   POST /v3/consent/hip/on-notify
   V3 Data:      POST /v3/hip/data/on-request
   ```

2. **Missing CORS headers:** Not needed for server-to-server callbacks, but if your framework adds them, ensure they don't block requests without an Origin header.

3. **Request body parsing:** Ensure your server parses JSON request bodies:
   ```javascript
   // Express.js
   app.use(express.json());

   // Without this, req.body is undefined
   ```

### Tunnel Disconnects Randomly

- Cloudflared quick tunnels are ephemeral. For long development sessions, set up a named tunnel.
- Check your internet connection stability.
- Some corporate firewalls block tunnel protocols. Try a different network.

---

## Production Considerations

In production, you won't use tunnels. Instead:

1. **Deploy your server** on a cloud provider (AWS, GCP, Azure) with a public IP or load balancer.
2. **Use HTTPS** with a valid SSL certificate (Let's Encrypt is free).
3. **Register a stable URL** (e.g., `https://abdm-bridge.your-hospital.com`).
4. **Ensure high availability** — if your bridge URL is down during a callback, the operation fails.
5. **Monitor callback health** — set up alerts if your callback endpoints start returning errors.

---

## Related

- [BRIDGE-1001: Bridge URL Not Registered](../errors/bridge-infrastructure-errors.md#bridge-1001--bridge-url-not-registered)
- [BRIDGE-1002: Callback Timeout](../errors/bridge-infrastructure-errors.md#bridge-1002--callback-timeout)
- [BRIDGE-1003: WAF Blocked](../errors/bridge-infrastructure-errors.md#bridge-1003--waf-blocked)
