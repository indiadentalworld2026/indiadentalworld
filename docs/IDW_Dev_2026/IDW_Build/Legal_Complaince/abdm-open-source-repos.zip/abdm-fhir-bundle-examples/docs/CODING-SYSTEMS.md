# Coding Systems Reference

Quick reference for the coding systems used in ABDM FHIR bundles. Use these codes when building your FHIR resources.

## SNOMED CT

**System URI**: `http://snomed.info/sct`

### Clinical Findings (Conditions)

| Code | Display | Common Use |
|------|---------|------------|
| 386661006 | Fever | Chief complaint |
| 29857009 | Chest pain | Chief complaint |
| 25064002 | Headache | Chief complaint |
| 62315008 | Diarrhoea | Chief complaint |
| 49727002 | Cough | Chief complaint |
| 267036007 | Breathlessness | Chief complaint |
| 38341003 | Hypertension | Diagnosis |
| 73211009 | Diabetes mellitus | Diagnosis |
| 195967001 | Asthma | Diagnosis |
| 22298006 | Myocardial infarction | Diagnosis |
| 38362002 | Dengue | Diagnosis |
| 34014006 | Viral disease | Diagnosis |
| 840539006 | COVID-19 | Diagnosis |
| 235595009 | Gastroesophageal reflux disease | Diagnosis |
| 13644009 | Hypercholesterolaemia | Diagnosis |
| 44054006 | Diabetes mellitus type 2 | Diagnosis |
| 46635009 | Diabetes mellitus type 1 | Diagnosis |

### Procedures

| Code | Display |
|------|---------|
| 415070008 | Percutaneous coronary intervention |
| 80146002 | Appendectomy |
| 274031008 | Caesarean section |
| 18027006 | Transplantation |
| 396550006 | Blood test |
| 82078001 | Collection of blood specimen for laboratory |
| 229065009 | Exercise therapy |

### Medications

| Code | Display |
|------|---------|
| 387207008 | Paracetamol |
| 387458008 | Aspirin |
| 372756006 | Clopidogrel |
| 376988009 | Atorvastatin |
| 387174006 | Domperidone |
| 387106007 | Metformin |
| 386864001 | Amlodipine |
| 373254001 | Pantoprazole |

### Encounter Types

| Code | Display |
|------|---------|
| 185349003 | Encounter for check up |
| 32485007 | Hospital admission |
| 390906007 | Follow-up encounter |

### Body Sites

| Code | Display |
|------|---------|
| 61396006 | Left thigh |
| 11207009 | Right thigh |
| 7311008 | Anterior cubital vein |
| 68787002 | Left anterior descending coronary artery |

### Routes of Administration

| Code | Display |
|------|---------|
| 26643006 | Oral route |
| 78421000 | Intramuscular route |
| 47625008 | Intravenous route |
| 34206005 | Subcutaneous route |

### Vaccines

| Code | Display |
|------|---------|
| 871751006 | Hepatitis B vaccine |
| 871875004 | Pentavalent vaccine (DTP-HepB-Hib) |
| 1119349007 | COVID-19 mRNA vaccine |
| 871831003 | BCG vaccine |
| 871740006 | Polio vaccine |
| 871765008 | Measles vaccine |

### Practitioner Roles

| Code | Display |
|------|---------|
| 309343006 | Physician |
| 17561000 | Cardiologist |
| 61246008 | Laboratory medicine specialist |
| 309395003 | Pediatrician |

### Composition Types

| Code | Display | hiType |
|------|---------|--------|
| 371530004 | Clinical consultation report | OPConsultation |
| 440545006 | Prescription record | Prescription |
| 721981007 | Diagnostic studies report | DiagnosticReport |
| 373942005 | Discharge summary | DischargeSummary |
| 41000179103 | Immunization record | ImmunizationRecord |
| 419891008 | Record artifact | WellnessRecord |

---

## LOINC

**System URI**: `http://loinc.org`

### Vital Signs

| Code | Display | Units |
|------|---------|-------|
| 85354-9 | Blood pressure panel | - (has components) |
| 8480-6 | Systolic blood pressure | mm[Hg] |
| 8462-4 | Diastolic blood pressure | mm[Hg] |
| 8867-4 | Heart rate | /min |
| 8310-5 | Body temperature | Cel or [degF] |
| 9279-1 | Respiratory rate | /min |
| 2708-6 | Oxygen saturation in Arterial blood | % |

### Body Measurements

| Code | Display | Units |
|------|---------|-------|
| 8302-2 | Body height | cm |
| 29463-7 | Body weight | kg |
| 39156-5 | Body mass index (BMI) | kg/m2 |

### Laboratory — Hematology

| Code | Display | Units |
|------|---------|-------|
| 58410-2 | CBC panel — Automated count | - (panel) |
| 718-7 | Hemoglobin | g/dL |
| 6690-2 | WBC count — Automated | /uL |
| 789-8 | RBC count — Automated | 10*6/uL |
| 777-3 | Platelet count — Automated | /uL |
| 4544-3 | Hematocrit — Automated | % |
| 787-2 | MCV — Automated | fL |

### Laboratory — Biochemistry

| Code | Display | Units |
|------|---------|-------|
| 2345-7 | Glucose [Mass/volume] in Serum or Plasma | mg/dL |
| 4548-4 | Hemoglobin A1c | % |
| 2093-3 | Total Cholesterol | mg/dL |
| 2571-8 | Triglycerides | mg/dL |
| 2085-9 | HDL Cholesterol | mg/dL |
| 13457-7 | LDL Cholesterol (calculated) | mg/dL |
| 2160-0 | Creatinine in Serum | mg/dL |
| 3094-0 | Urea nitrogen in Serum | mg/dL |
| 1742-6 | ALT (SGPT) | U/L |
| 1920-8 | AST (SGOT) | U/L |
| 1975-2 | Bilirubin, total | mg/dL |
| 14959-1 | TSH | mIU/L |

### Sections

| Code | Display |
|------|---------|
| 8716-3 | Vital signs |
| 18842-5 | Discharge summary |
| 35094-2 | Blood pressure panel |

---

## ICD-10

**System URI**: `http://hl7.org/fhir/sid/icd-10`

### Common Diagnoses

| Code | Display |
|------|---------|
| A90 | Dengue fever [classical dengue] |
| A91 | Dengue haemorrhagic fever |
| E11 | Type 2 diabetes mellitus |
| E10 | Type 1 diabetes mellitus |
| I10 | Essential (primary) hypertension |
| I21.0 | Acute transmural MI of anterior wall |
| I21.1 | Acute transmural MI of inferior wall |
| J06.9 | Acute upper respiratory infection, unspecified |
| J18.9 | Pneumonia, unspecified organism |
| J45 | Asthma |
| K21 | Gastro-oesophageal reflux disease |
| U07.1 | COVID-19 |
| N18 | Chronic kidney disease |
| B15 | Acute hepatitis A |
| B16 | Acute hepatitis B |

---

## FHIR Standard Code Systems

### Observation Category
**System**: `http://terminology.hl7.org/CodeSystem/observation-category`

| Code | Display |
|------|---------|
| vital-signs | Vital Signs |
| laboratory | Laboratory |
| social-history | Social History |

### Condition Category
**System**: `http://terminology.hl7.org/CodeSystem/condition-category`

| Code | Display |
|------|---------|
| encounter-diagnosis | Encounter Diagnosis |
| problem-list-item | Problem List Item |

### Encounter Class
**System**: `http://terminology.hl7.org/CodeSystem/v3-ActCode`

| Code | Display |
|------|---------|
| AMB | ambulatory |
| IMP | inpatient encounter |
| EMER | emergency |

### Observation Interpretation
**System**: `http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation`

| Code | Display |
|------|---------|
| N | Normal |
| H | High |
| L | Low |
| HH | Critical high |
| LL | Critical low |

### Units of Measure
**System**: `http://unitsofmeasure.org`

| Code | Display |
|------|---------|
| mm[Hg] | mmHg |
| /min | per minute |
| Cel | degrees Celsius |
| [degF] | degrees Fahrenheit |
| % | percent |
| mg | milligrams |
| g/dL | grams per deciliter |
| mg/dL | milligrams per deciliter |
| /uL | per microliter |
| 10*6/uL | million per microliter |
| fL | femtoliters |
| cm | centimeters |
| kg | kilograms |
| kg/m2 | kilograms per square meter |
| mL | milliliters |
| U/L | units per liter |
| mIU/L | milli-international units per liter |

---

## NRCES Profile Base URL

All NRCES profiles are under:
```
https://nrces.in/ndhm/fhir/r4/StructureDefinition/
```

Append the profile name listed in [`schemas/bundle-validation-notes.md`](../schemas/bundle-validation-notes.md).
