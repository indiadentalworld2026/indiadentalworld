# Bridge & Infrastructure Errors

These errors relate to the bridge infrastructure — the communication layer between your system and the ABDM gateway. Your "bridge URL" is the public endpoint where ABDM sends callbacks, notifications, and discovery requests to your system.

---

### BRIDGE-1001 — Bridge URL Not Registered

**Error Response:**
```json
{
  "code": "BRIDGE-1001",
  "message": "Bridge URL Not Registered",
  "details": {
    "facilityId": "IN2710004770",
    "message": "No callback URL registered for this facility"
  }
}
```

**What causes this:**

Your facility (HIP/HIU) does not have a bridge URL registered with ABDM. Without a registered URL, ABDM has nowhere to send callbacks for discovery, consent notifications, and data transfer requests.

**How to fix it:**

**Option 1: Register via API (V3)**
```bash
curl -X PATCH 'https://dev.abdm.gov.in/api/hiecm/gateway/v3/bridge/url' \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer YOUR_TOKEN' \
  -d '{
    "url": "https://your-server.example.com"
  }'
```

**Option 2: Register via Sandbox Portal (recommended)**
1. Log into [sandbox.abdm.gov.in](https://sandbox.abdm.gov.in)
2. Navigate to your registered facility
3. Update the bridge URL in the facility settings
4. Save and verify

**Important notes:**
- The URL must be **HTTPS** in production. Sandbox may accept HTTP for development.
- The URL must be publicly accessible — not `localhost` or an internal IP.
- For local development, use a tunnel service. See [Callback Debugging](../troubleshooting/callback-debugging.md).
- Bridge URL updates via API are sometimes blocked by CloudFront WAF. If you get a WAF error, use the portal UI instead (see BRIDGE-1003).

---

### BRIDGE-1002 — Callback Timeout

**Error Response:**
```json
{
  "code": "BRIDGE-1002",
  "message": "Callback Timeout",
  "details": {
    "url": "https://your-server.example.com/v3/hip/patient/on-discover",
    "timeoutMs": 30000,
    "message": "ABDM could not reach your callback URL within the timeout period"
  }
}
```

**What causes this:**

ABDM attempted to call your bridge URL but either:
- Your server didn't respond within the timeout window (typically 30 seconds)
- Your server was unreachable (DNS resolution failed, connection refused)
- A firewall or security group blocked the incoming request
- Your tunnel (ngrok/cloudflared) was disconnected

**How to fix it:**

1. **Verify your server is running and accessible:**
   ```bash
   # Test from a different machine or use an online tool
   curl -v https://your-server.example.com/health
   ```

2. **Check your tunnel (if using one):**
   ```bash
   # Cloudflared
   cloudflared tunnel --url http://localhost:3200

   # Verify the tunnel URL is working
   curl https://your-tunnel-id.trycloudflare.com/health
   ```

3. **Ensure your endpoints respond quickly.** ABDM has a ~30 second timeout. If your discovery logic takes longer:
   - Respond with an acknowledgment immediately
   - Process asynchronously
   - In V3 synchronous discovery, optimize your patient lookup to be fast

4. **Check firewall rules:**
   - ABDM callbacks come from AWS IP ranges (they use CloudFront)
   - Don't restrict inbound IPs too aggressively in sandbox
   - Ensure your cloud provider's security groups allow inbound HTTPS

5. **Check DNS:** If you recently changed your bridge URL, DNS propagation may take time. Use `dig` or `nslookup` to verify.

**Full guide:** [Callback URL Debugging](../troubleshooting/callback-debugging.md)

---

### BRIDGE-1003 — WAF Blocked

**Error Response:**
```json
{
  "code": "BRIDGE-1003",
  "message": "Request blocked",
  "details": {
    "reason": "CloudFront WAF rejected the request"
  }
}
```

Or you may see a raw CloudFront error page:
```html
<!DOCTYPE html>
<html>
<head><title>403 ERROR</title></head>
<body>
<h1>403 ERROR</h1>
<p>The request could not be satisfied.</p>
<p>Request blocked.</p>
</body>
</html>
```

**What causes this:**

AWS CloudFront's Web Application Firewall (WAF) is blocking your request. This is a known issue that particularly affects:
- Bridge URL update API calls (`PATCH /gateway/v3/bridge/url`)
- Requests with certain URL patterns or payloads that trigger WAF rules
- Requests from certain IP ranges or regions

This is an ABDM infrastructure issue, not a problem with your code.

**How to fix it:**

1. **Use the sandbox portal UI as a workaround:**
   - Log into [sandbox.abdm.gov.in](https://sandbox.abdm.gov.in)
   - Update your bridge URL through the web interface
   - The portal doesn't go through the same WAF rules

2. **If you must use the API:**
   - Try from a different IP address or region
   - Ensure your request headers don't include unusual values
   - Remove any custom headers that aren't required
   - Try without URL-encoded special characters in the payload

3. **For production:** If WAF blocks are occurring in production, raise an urgent ticket on [devforum.abdm.gov.in](https://devforum.abdm.gov.in). Include:
   - Your client ID
   - The exact endpoint and HTTP method
   - The CloudFront request ID (from the error response headers: `x-amz-cf-id`)
   - Timestamp of the blocked request

**Cross-reference:** This error can sometimes masquerade as a generic 403. If you're seeing 403 without the `900908` code, it might be WAF. Check if the response body is HTML (CloudFront) vs JSON (WSO2 gateway).
