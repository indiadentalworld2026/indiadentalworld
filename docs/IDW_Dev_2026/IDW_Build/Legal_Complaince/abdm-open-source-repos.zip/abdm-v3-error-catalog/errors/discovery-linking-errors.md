# Discovery & Linking Errors

These errors occur during the patient discovery and care context linking workflows. Discovery is how ABDM finds a patient's records in your system (HIP). Linking is how those records are associated with the patient's ABHA for future data access.

> In V3, discovery is **synchronous** — you return the response in the HTTP body. This is a major change from v0.5 where discovery used async callbacks.

---

### LINK-1001 — Patient Not Found

**Error Response:**
```json
{
  "code": "LINK-1001",
  "message": "Patient Not Found",
  "details": {
    "reason": "No matching patient found in the HIP system",
    "identifiers": {
      "abhaNumber": "91-2345-6789-0123",
      "abhaAddress": "john@abdm"
    }
  }
}
```

**What causes this:**

When ABDM sends a discovery request to your HIP (Health Information Provider), your system could not find a matching patient. This happens on your side — your system returns this error to ABDM.

Reasons:
- The patient doesn't have records in your system
- Your patient matching logic is too strict (exact match when fuzzy is needed)
- ABHA number is stored in a different format in your database
- The patient registered with different demographics in your system

**How to fix it:**

1. **Check your patient matching logic.** ABDM sends these identifiers for discovery:
   - ABHA number
   - ABHA address
   - Name
   - Gender
   - Year of birth

2. **Implement fuzzy matching** — don't require exact matches on all fields:
   ```
   Match priority:
   1. ABHA number (exact match) — most reliable
   2. ABHA address (exact match)
   3. Name + Gender + Year of birth (fuzzy match)
   ```

3. **Normalize ABHA numbers** before comparison: strip hyphens, spaces, leading/trailing whitespace.

4. **V3 synchronous discovery response:**
   ```json
   // Return directly in HTTP response body
   {
     "patient": {
       "referenceNumber": "pat-123",
       "display": "John Doe",
       "careContexts": [
         {
           "referenceNumber": "visit-456",
           "display": "OPD Visit - 2026-03-15"
         }
       ]
     }
   }
   ```

5. If the patient genuinely doesn't exist in your system, return an appropriate error — this is not a bug, it's a valid scenario.

---

### LINK-1002 — Care Context Already Linked

**Error Response:**
```json
{
  "code": "LINK-1002",
  "message": "Care Context Already Linked",
  "details": {
    "careContextReference": "visit-456",
    "linkedAt": "2026-03-10T09:00:00.000Z"
  }
}
```

**What causes this:**

You're attempting to link a care context that is already linked to the patient's ABHA. Each care context can only be linked once.

**How to fix it:**

1. **Check existing links before attempting to link.** Maintain a local record of which care contexts are already linked.

2. **Skip already-linked contexts** during the linking flow:
   ```python
   for care_context in discovery_response.care_contexts:
       if not is_already_linked(care_context.reference):
           link_care_context(care_context)
       else:
           log.info(f"Skipping {care_context.reference} — already linked")
   ```

3. **During discovery, you can still return already-linked care contexts** in the response — ABDM handles the deduplication. But during the link confirmation step, only include new ones.

4. This is not an error in the strict sense — it's a guard against duplicate linking. Handle it gracefully.

---

### LINK-1003 — Link Token Expired

**Error Response:**
```json
{
  "code": "LINK-1003",
  "message": "Link Token Expired",
  "details": {
    "tokenExpiry": "2026-03-17T14:00:00.000Z",
    "message": "HIP-initiated linking token has expired"
  }
}
```

**What causes this:**

During HIP-initiated linking, a token is generated that the patient must confirm. This token expires after **30 minutes**. If the patient doesn't confirm within that window, the token becomes invalid.

**How to fix it:**

1. Generate a new linking token by restarting the HIP-initiated linking flow.
2. Prompt the patient to confirm quickly — communicate the time limit in your UI.
3. Implement a notification system: send the patient a push notification or SMS when a link confirmation is pending.
4. Consider starting the linking flow only when the patient is actively present (e.g., during a clinic visit).

---

### LINK-1004 — Token Verification Failed

**Error Response:**
```json
{
  "code": "LINK-1004",
  "message": "Token Verification Failed",
  "details": {
    "reason": "Profile share token verification failed",
    "tokenId": "tok-..."
  }
}
```

**What causes this:**

The token from a patient-share session failed verification. This occurs during the V3 patient-share workflow where a patient shares their profile via a QR code or deep link.

**Known V3 issue:** This error has been reported intermittently in the V3 sandbox. The token may be valid but verification fails due to a timing issue on the ABDM side.

**How to fix it:**

1. **Retry the operation.** This error is often transient in V3. Wait 2-3 seconds and retry.
2. Ensure the token matches the exact patient-share session. Don't reuse tokens across sessions.
3. Verify that your system clock is synchronized (NTP). Token verification is time-sensitive.
4. If retries consistently fail:
   - Check that you're using the V3 patient-share endpoint (not v0.5)
   - Verify the token hasn't been consumed by a previous successful verification
   - Report the issue on [devforum.abdm.gov.in](https://devforum.abdm.gov.in) with the token ID and timestamp

**Cross-reference:** If you're getting 403 errors on patient-share endpoints, see [900908](gateway-errors.md#900908--api-subscription-validation-failed) — this module may not be enabled for your client ID in V3.
