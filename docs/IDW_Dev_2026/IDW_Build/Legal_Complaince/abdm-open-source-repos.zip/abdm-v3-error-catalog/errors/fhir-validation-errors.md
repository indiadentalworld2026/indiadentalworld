# FHIR Validation Errors

These errors occur when the FHIR (Fast Healthcare Interoperability Resources) bundles you submit don't conform to ABDM's expected structure. ABDM uses FHIR R4 with Indian-specific profiles defined by NRCES (National Resource Centre for EHR Standards).

> For a step-by-step debugging workflow, see [FHIR Bundle Debugging](../troubleshooting/fhir-bundle-debugging.md).

---

### FHIR-1001 — Invalid Bundle

**Error Response:**
```json
{
  "code": "FHIR-1001",
  "message": "Invalid Bundle",
  "details": {
    "reason": "FHIR bundle does not conform to expected structure",
    "issues": [
      {
        "severity": "error",
        "code": "structure",
        "diagnostics": "Bundle.type must be 'document' or 'collection'"
      }
    ]
  }
}
```

**What causes this:**

The FHIR bundle structure is invalid. This can mean many things:
- `Bundle.type` is not `document` (most ABDM submissions require document bundles)
- `Bundle.entry[0]` is not a `Composition` resource (required for document bundles)
- Missing `Bundle.meta.lastUpdated` or `Bundle.timestamp`
- The bundle is syntactically valid JSON but not valid FHIR

**How to fix it:**

1. **Validate locally first** using the HL7 FHIR Validator:
   ```bash
   java -jar validator_cli.jar your-bundle.json \
     -ig https://nrces.in/ndhm/fhir/r4/ImplementationGuide/ndhm.nrces
   ```

2. **Ensure document bundle structure:**
   ```json
   {
     "resourceType": "Bundle",
     "id": "bundle-01",
     "type": "document",
     "timestamp": "2026-03-18T10:00:00.000Z",
     "meta": {
       "lastUpdated": "2026-03-18T10:00:00.000Z"
     },
     "entry": [
       {
         "fullUrl": "urn:uuid:composition-01",
         "resource": {
           "resourceType": "Composition",
           "status": "final",
           "type": { ... },
           "subject": { "reference": "urn:uuid:patient-01" },
           "date": "2026-03-18",
           "author": [{ "reference": "urn:uuid:practitioner-01" }],
           "section": [ ... ]
         }
       },
       {
         "fullUrl": "urn:uuid:patient-01",
         "resource": {
           "resourceType": "Patient",
           ...
         }
       }
     ]
   }
   ```

3. **Check NRCES profile conformance:** Different `hiTypes` have different profile requirements. See FHIR-1002 below.

---

### FHIR-1002 — Missing Required Resource

**Error Response:**
```json
{
  "code": "FHIR-1002",
  "message": "Missing Required Resource",
  "details": {
    "hiType": "OPConsultation",
    "missingResources": ["Encounter", "Patient"]
  }
}
```

**What causes this:**

Your FHIR bundle is missing one or more mandatory resources for the specified `hiType` (Health Information Type).

**Minimum required resources by hiType:**

| hiType | Required Resources |
|--------|--------------------|
| OPConsultation | Composition, Patient, Encounter, Practitioner |
| Prescription | Composition, Patient, MedicationRequest, Practitioner |
| DiagnosticReport | Composition, Patient, DiagnosticReport, Observation |
| DischargeSummary | Composition, Patient, Encounter, Condition, Practitioner |
| ImmunizationRecord | Composition, Patient, Immunization |
| HealthDocumentRecord | Composition, Patient, DocumentReference |
| WellnessRecord | Composition, Patient, Observation |

**How to fix it:**

1. Check which `hiType` you're submitting for and include all mandatory resources.
2. Every resource referenced in `Composition.section` entries must exist as a `Bundle.entry`.
3. The `Patient` resource is **always** required, regardless of `hiType`.
4. The `Composition` resource must **always** be the first entry in the bundle.

---

### FHIR-1003 — Duplicate Bundle Identifier

**Error Response:**
```json
{
  "code": "FHIR-1003",
  "message": "Duplicate Bundle Identifier",
  "details": {
    "identifier": "bundle-12345",
    "message": "A bundle with this identifier has already been submitted"
  }
}
```

**What causes this:**

You submitted a FHIR bundle with a `Bundle.id` or `Bundle.identifier` that was already used in a previous submission. ABDM enforces uniqueness to prevent duplicate data.

**How to fix it:**

1. **Always generate a fresh UUID** for every bundle:
   ```json
   {
     "resourceType": "Bundle",
     "id": "urn:uuid:a1b2c3d4-e5f6-7890-abcd-ef1234567890",
     "identifier": {
       "system": "https://your-system.com/bundles",
       "value": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
     }
   }
   ```

2. **Never reuse bundle IDs**, even if the previous submission failed. Treat every submission as unique.

3. Use your programming language's UUID v4 generator:
   ```python
   import uuid
   bundle_id = f"urn:uuid:{uuid.uuid4()}"
   ```
   ```javascript
   const bundleId = `urn:uuid:${crypto.randomUUID()}`;
   ```
   ```go
   bundleId := fmt.Sprintf("urn:uuid:%s", uuid.New().String())
   ```

---

### FHIR-1004 — Broken Resource Reference

**Error Response:**
```json
{
  "code": "FHIR-1004",
  "message": "Broken Resource Reference",
  "details": {
    "source": "Composition.subject",
    "reference": "urn:uuid:patient-01",
    "message": "Referenced resource not found in bundle"
  }
}
```

**What causes this:**

A resource within the bundle references another resource (via `reference` field) that doesn't exist in the bundle. For example, `Composition.subject.reference` points to `urn:uuid:patient-01`, but no entry in the bundle has `fullUrl: "urn:uuid:patient-01"`.

**How to fix it:**

1. **Ensure every reference has a matching `fullUrl`:**
   ```json
   // Composition references the patient
   "subject": {
     "reference": "urn:uuid:patient-01"
   }

   // Patient entry must have matching fullUrl
   {
     "fullUrl": "urn:uuid:patient-01",
     "resource": {
       "resourceType": "Patient",
       ...
     }
   }
   ```

2. **Check for typos and case sensitivity:** `urn:uuid:Patient-01` is NOT the same as `urn:uuid:patient-01`.

3. **Audit all references** in your bundle. Common reference fields to check:
   - `Composition.subject` → Patient
   - `Composition.author` → Practitioner or Organization
   - `Composition.encounter` → Encounter
   - `Composition.section[].entry[]` → Various resources
   - `Encounter.subject` → Patient
   - `MedicationRequest.subject` → Patient
   - `DiagnosticReport.subject` → Patient
   - `Observation.subject` → Patient

4. **Write a validation function** that extracts all `fullUrl` values and all `reference` values from the bundle, then checks that every reference has a corresponding `fullUrl`.
