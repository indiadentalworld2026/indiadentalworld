# Token Management for ABDM APIs

ABDM gateway tokens expire after **5 minutes**. This is aggressively short, and if you don't manage tokens properly, you'll see `900901 Invalid Credentials` errors constantly. This guide covers how to handle it.

---

## How ABDM Tokens Work

1. You call `/v3/sessions` with your client ID and secret.
2. You receive an `accessToken` with a 5-minute TTL.
3. Every subsequent API call must include this token in the `Authorization: Bearer` header.
4. After 5 minutes, the token is dead. No refresh mechanism — you must call `/sessions` again.

```bash
curl -X POST 'https://dev.abdm.gov.in/api/hiecm/gateway/v3/sessions' \
  -H 'Content-Type: application/json' \
  -d '{
    "clientId": "YOUR_CLIENT_ID",
    "clientSecret": "YOUR_CLIENT_SECRET"
  }'
```

Response:
```json
{
  "accessToken": "eyJhbGciOiJSUzI1NiIs...",
  "expiresIn": 300,
  "tokenType": "bearer"
}
```

---

## The Problem

5 minutes is not much. If you:
- Fetch a token at 10:00:00
- Make API calls at 10:04:30
- Your next call at 10:05:01 **fails** with `900901`

Even worse, token generation itself takes 1-3 seconds, so your effective window is more like 4 minutes 57 seconds.

---

## Recommended Strategy: Preemptive Refresh

Don't wait for a 401 to refresh. Instead, refresh proactively when the token is about to expire.

### Implementation Pattern

```python
import time
import requests
from threading import Lock

class ABDMTokenManager:
    def __init__(self, client_id, client_secret, base_url):
        self.client_id = client_id
        self.client_secret = client_secret
        self.base_url = base_url
        self.token = None
        self.expires_at = 0
        self.lock = Lock()
        # Refresh 60 seconds before expiry to be safe
        self.refresh_buffer = 60

    def get_token(self):
        with self.lock:
            now = time.time()
            if self.token is None or now >= (self.expires_at - self.refresh_buffer):
                self._refresh_token()
            return self.token

    def _refresh_token(self):
        response = requests.post(
            f"{self.base_url}/v3/sessions",
            json={
                "clientId": self.client_id,
                "clientSecret": self.client_secret
            }
        )
        data = response.json()
        self.token = data["accessToken"]
        # expiresIn is in seconds (300 = 5 minutes)
        self.expires_at = time.time() + data["expiresIn"]

# Usage
token_manager = ABDMTokenManager(
    client_id="SBXID_XXXXXX",
    client_secret="your-secret",
    base_url="https://dev.abdm.gov.in/api/hiecm/gateway"
)

# Always get a valid token before any API call
headers = {
    "Authorization": f"Bearer {token_manager.get_token()}",
    "Content-Type": "application/json"
}
```

```javascript
// Node.js implementation
class ABDMTokenManager {
  constructor(clientId, clientSecret, baseUrl) {
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.baseUrl = baseUrl;
    this.token = null;
    this.expiresAt = 0;
    this.refreshBuffer = 60; // seconds
    this.refreshPromise = null;
  }

  async getToken() {
    const now = Date.now() / 1000;
    if (!this.token || now >= this.expiresAt - this.refreshBuffer) {
      // Deduplicate concurrent refresh calls
      if (!this.refreshPromise) {
        this.refreshPromise = this._refresh().finally(() => {
          this.refreshPromise = null;
        });
      }
      await this.refreshPromise;
    }
    return this.token;
  }

  async _refresh() {
    const response = await fetch(`${this.baseUrl}/v3/sessions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        clientId: this.clientId,
        clientSecret: this.clientSecret,
      }),
    });
    const data = await response.json();
    this.token = data.accessToken;
    this.expiresAt = Date.now() / 1000 + data.expiresIn;
  }
}
```

```go
// Go implementation
type ABDMTokenManager struct {
    clientID     string
    clientSecret string
    baseURL      string
    token        string
    expiresAt    time.Time
    mu           sync.Mutex
    buffer       time.Duration
}

func NewABDMTokenManager(clientID, clientSecret, baseURL string) *ABDMTokenManager {
    return &ABDMTokenManager{
        clientID:     clientID,
        clientSecret: clientSecret,
        baseURL:      baseURL,
        buffer:       60 * time.Second,
    }
}

func (m *ABDMTokenManager) GetToken(ctx context.Context) (string, error) {
    m.mu.Lock()
    defer m.mu.Unlock()

    if m.token == "" || time.Now().After(m.expiresAt.Add(-m.buffer)) {
        if err := m.refresh(ctx); err != nil {
            return "", err
        }
    }
    return m.token, nil
}
```

---

## Common Mistakes

### 1. Caching the Token for Too Long

Don't store the token in a config file or environment variable and forget about it. It expires in 5 minutes.

### 2. Missing the "Bearer " Prefix

```
WRONG:  Authorization: eyJhbGciOiJSUzI1NiIs...
RIGHT:  Authorization: Bearer eyJhbGciOiJSUzI1NiIs...
```

There must be exactly one space between `Bearer` and the token.

### 3. Token from Wrong Environment

Sandbox tokens don't work in production. Production tokens don't work in sandbox.

```
Sandbox:    https://dev.abdm.gov.in/api/hiecm/gateway/v3/sessions
Production: https://live.abdm.gov.in/api/hiecm/gateway/v3/sessions
```

### 4. Not Handling Concurrent Requests

If multiple threads/requests try to refresh the token simultaneously, you'll make redundant calls and potentially cause rate limiting. Use a mutex/lock as shown in the examples above.

### 5. Retrying Without Refreshing

If you get a 401, refresh the token BEFORE retrying. Don't retry with the same expired token.

```python
# WRONG
for attempt in range(3):
    response = call_abdm_api(token)
    if response.status_code != 401:
        break

# RIGHT
for attempt in range(3):
    token = token_manager.get_token()  # Gets fresh token if needed
    response = call_abdm_api(token)
    if response.status_code == 401:
        token_manager.invalidate()  # Force refresh on next call
        continue
    break
```

---

## Retry Logic with Token Refresh

A robust pattern that handles both token expiry and transient errors:

```python
def call_abdm_with_retry(token_manager, method, url, payload, max_retries=3):
    for attempt in range(max_retries):
        token = token_manager.get_token()
        response = requests.request(
            method, url,
            json=payload,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            }
        )

        if response.status_code == 401:
            # Token expired mid-request, force refresh
            token_manager.invalidate()
            continue

        if response.status_code == 500:
            # Server error, wait and retry
            time.sleep(2 ** attempt)  # Exponential backoff
            continue

        return response

    raise Exception(f"ABDM API call failed after {max_retries} retries")
```

---

## Related

- [Gateway Error 900901](../errors/gateway-errors.md#900901--invalid-credentials)
- [Gateway Error 900902](../errors/gateway-errors.md#900902--missing-credentials)
- [HTTP 401 Reference](../errors/http-status-codes.md#401--unauthorized)
