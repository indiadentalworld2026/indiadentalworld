# Authentication Guide

## Overview

ABDM V3 APIs use a session-based access token obtained via client credentials. All API requests (except the session endpoint itself) require a valid Bearer token in the `Authorization` header.

## How Authentication Works

### 1. Obtain Access Token

**Endpoint:** `POST /gateway/v3/sessions`

```json
{
  "clientId": "YOUR_SBXID",
  "clientSecret": "YOUR_SECRET",
  "grantType": "client_credentials"
}
```

**Response:**
```json
{
  "accessToken": "eyJhbGciOiJSUzI1NiIsInR5cCI6...",
  "expiresIn": 1800,
  "tokenType": "bearer"
}
```

### 2. Use the Token

Include the token in every subsequent request:

```
Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6...
```

### 3. Token Expiry

Tokens expire after approximately **30 minutes** (1800 seconds). The collection's pre-request script handles automatic refresh.

## Auto-Authentication in This Collection

The collection includes a pre-request script at the collection level that:

1. Checks if `accessToken` exists and is not expired
2. If expired or missing, calls `/gateway/v3/sessions` with your `clientId` and `clientSecret`
3. Stores the new token in the `accessToken` environment variable
4. Stores the expiry timestamp in `tokenExpiry` for subsequent checks

This means you can run any request in the collection without manually authenticating first — the script handles it transparently.

## Token Scopes

The access token scope depends on your bridge registration:

| Role | Capabilities |
|---|---|
| **HIP** (Health Information Provider) | Respond to discovery, linking, serve health data |
| **HIU** (Health Information User) | Request consent, fetch health records |
| **HRP** (Health Repository Provider) | Store and manage health records |
| **DIGI_DOCTOR** | Digital doctor services |
| **HFR** (Health Facility Registry) | Facility management |

Your bridge can have multiple roles. The token grants access based on all registered roles.

## Sandbox vs Production Credentials

| | Sandbox | Production |
|---|---|---|
| **Session URL** | `https://dev.abdm.gov.in/gateway/v3/sessions` | `https://apis.abdm.gov.in/gateway/v3/sessions` |
| **Client ID Format** | `SBXID_XXXXXX` | Organization-specific |
| **Registration** | [sandbox.abdm.gov.in](https://sandbox.abdm.gov.in) | [abdm.gov.in](https://abdm.gov.in) |

## Security Best Practices

1. **Never commit credentials** — Use Postman environment variables (type: `secret`)
2. **Rotate secrets** periodically through the ABDM portal
3. **Use separate credentials** for sandbox and production
4. **Do not share** exported environments containing filled-in secrets

## Common Auth Errors

| Error | Cause | Fix |
|---|---|---|
| `401 Unauthorized` | Token expired or invalid | Re-authenticate via the session endpoint |
| `403 Forbidden` | WSO2 subscription issue or role mismatch | Check your bridge roles in the sandbox portal |
| `Invalid client credentials` | Wrong clientId or clientSecret | Verify credentials in the sandbox portal |
| `Grant type not supported` | Wrong grantType value | Must be `"client_credentials"` |
