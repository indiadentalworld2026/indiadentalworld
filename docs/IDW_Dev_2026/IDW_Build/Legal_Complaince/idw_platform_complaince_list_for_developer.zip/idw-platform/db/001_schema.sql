-- IDW compliance core: schema
-- Target: PostgreSQL 14+ (AWS RDS, Mumbai region).
-- Anything marked LEGAL-PLACEHOLDER is a value your lawyer must confirm before launch.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------- types
CREATE TYPE user_role AS ENUM (
  'patient', 'clinic_owner', 'lab_owner', 'vendor_owner', 'institute_owner',
  'verifier', 'grievance_officer', 'admin'
);
CREATE TYPE user_status AS ENUM ('active', 'deletion_pending', 'deleted');
CREATE TYPE org_type AS ENUM ('clinic', 'lab', 'vendor', 'institute');
CREATE TYPE verification_status AS ENUM ('unverified', 'pending', 'verified', 'rejected', 'expired');
CREATE TYPE submission_status AS ENUM ('submitted', 'in_review', 'approved', 'rejected');
CREATE TYPE consent_purpose AS ENUM (
  'privacy_notice', 'terms', 'location', 'search_history', 'marketing_email', 'marketing_whatsapp'
);
CREATE TYPE request_kind AS ENUM ('export', 'delete');
CREATE TYPE request_status AS ENUM ('received', 'in_progress', 'completed', 'rejected');
CREATE TYPE appointment_status AS ENUM ('booked', 'completed', 'cancelled', 'no_show');
CREATE TYPE moderation_status AS ENUM ('visible', 'hidden');
CREATE TYPE grievance_status AS ENUM ('received', 'in_progress', 'resolved', 'closed');

-- ---------------------------------------------------------------- settings
-- Values that depend on legal advice live here, not in code.
CREATE TABLE settings (
  key          text PRIMARY KEY,
  value        text NOT NULL,
  description  text NOT NULL,
  legal_status text NOT NULL DEFAULT 'placeholder' CHECK (legal_status IN ('placeholder', 'approved')),
  approved_by  text,
  approved_at  timestamptz
);

-- Revenue features stay off until a named person records legal approval.
CREATE TABLE feature_flags (
  key         text PRIMARY KEY,
  enabled     boolean NOT NULL DEFAULT false,
  description text NOT NULL,
  approved_by text,
  approved_at timestamptz,
  CONSTRAINT enabled_needs_approval CHECK (NOT enabled OR (approved_by IS NOT NULL AND approved_at IS NOT NULL))
);

-- ---------------------------------------------------------------- people
CREATE TABLE users (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role        user_role NOT NULL,
  phone       text,
  email       text,
  full_name   text,
  status      user_status NOT NULL DEFAULT 'active',
  created_at  timestamptz NOT NULL DEFAULT now(),
  deleted_at  timestamptz
);
CREATE UNIQUE INDEX users_phone_live ON users (phone) WHERE status <> 'deleted' AND phone IS NOT NULL;
CREATE UNIQUE INDEX users_email_live ON users (lower(email)) WHERE status <> 'deleted' AND email IS NOT NULL;

CREATE TABLE organisations (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type                org_type NOT NULL,
  name                text NOT NULL,
  owner_user_id       uuid NOT NULL REFERENCES users(id),
  verification_status verification_status NOT NULL DEFAULT 'unverified',
  verified_at         timestamptz,
  verification_expires_at timestamptz,
  created_at          timestamptz NOT NULL DEFAULT now(),
  -- an organisation can only be marked verified together with an expiry date
  CONSTRAINT verified_has_dates CHECK (
    verification_status <> 'verified' OR (verified_at IS NOT NULL AND verification_expires_at IS NOT NULL))
);

-- ---------------------------------------------------------------- consent
-- Notice wording is stored as numbered, unchangeable versions.
CREATE TABLE notice_versions (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purpose      consent_purpose NOT NULL,
  version      integer NOT NULL CHECK (version > 0),
  body         text NOT NULL,
  legal_status text NOT NULL DEFAULT 'placeholder' CHECK (legal_status IN ('placeholder', 'approved')),
  published_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (purpose, version)
);

-- One row per decision. Never updated or deleted by the application.
CREATE TABLE consents (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           uuid NOT NULL REFERENCES users(id),
  purpose           consent_purpose NOT NULL,
  notice_version_id uuid NOT NULL REFERENCES notice_versions(id),
  granted           boolean NOT NULL,
  source            text NOT NULL CHECK (source IN ('web', 'app', 'whatsapp', 'admin')),
  recorded_at       timestamptz NOT NULL DEFAULT clock_timestamp(),
  seq               bigserial NOT NULL           -- strict order of decisions, even within one transaction
);
CREATE INDEX consents_user_purpose ON consents (user_id, purpose, seq DESC);

-- ---------------------------------------------------------------- audit
-- Append-only, hash-chained: any edit or deletion of history is detectable.
CREATE TABLE audit_log (
  id            bigserial PRIMARY KEY,
  at            timestamptz NOT NULL DEFAULT clock_timestamp(),
  actor_user_id uuid,
  action        text NOT NULL,
  entity_type   text NOT NULL,
  entity_id     text NOT NULL,
  details       jsonb NOT NULL DEFAULT '{}'::jsonb,
  prev_hash     text NOT NULL,
  hash          text NOT NULL
);

-- ---------------------------------------------------------------- data rights
CREATE TABLE data_requests (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES users(id),
  kind          request_kind NOT NULL,
  status        request_status NOT NULL DEFAULT 'received',
  received_at   timestamptz NOT NULL DEFAULT now(),
  due_at        timestamptz NOT NULL,
  completed_at  timestamptz,
  resolution_note text
);

CREATE TABLE grievances (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid REFERENCES users(id),
  contact_name  text NOT NULL,
  contact_info  text NOT NULL,
  category      text NOT NULL,
  body          text NOT NULL,
  status        grievance_status NOT NULL DEFAULT 'received',
  received_at   timestamptz NOT NULL DEFAULT now(),
  due_at        timestamptz NOT NULL,
  resolved_at   timestamptz,
  officer_id    uuid REFERENCES users(id)
);

-- ---------------------------------------------------------------- verification
CREATE TABLE verification_submissions (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id              uuid NOT NULL REFERENCES organisations(id),
  submitted_by        uuid NOT NULL REFERENCES users(id),
  registration_number text NOT NULL,
  issuing_body        text NOT NULL,          -- e.g. state dental council
  document_ref        text NOT NULL,          -- storage key of the uploaded document
  status              submission_status NOT NULL DEFAULT 'submitted',
  submitted_at        timestamptz NOT NULL DEFAULT now(),
  reviewed_by         uuid REFERENCES users(id),
  reviewed_at         timestamptz,
  decision_reason     text,
  CONSTRAINT decided_has_reviewer CHECK (
    status NOT IN ('approved', 'rejected') OR (reviewed_by IS NOT NULL AND reviewed_at IS NOT NULL)),
  CONSTRAINT rejected_has_reason CHECK (status <> 'rejected' OR coalesce(decision_reason, '') <> '')
);

-- ---------------------------------------------------------------- bookings and reviews
CREATE TABLE appointments (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id  uuid NOT NULL REFERENCES users(id),
  org_id      uuid NOT NULL REFERENCES organisations(id),
  slot_at     timestamptz NOT NULL,
  status      appointment_status NOT NULL DEFAULT 'booked'
);

CREATE TABLE reviews (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id uuid NOT NULL UNIQUE REFERENCES appointments(id),
  patient_id     uuid NOT NULL REFERENCES users(id),
  org_id         uuid NOT NULL REFERENCES organisations(id),
  rating         smallint NOT NULL CHECK (rating BETWEEN 1 AND 5),
  body           text NOT NULL,
  moderation     moderation_status NOT NULL DEFAULT 'visible',
  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE review_replies (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id  uuid NOT NULL UNIQUE REFERENCES reviews(id),
  author_id  uuid NOT NULL REFERENCES users(id),
  body       text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------- sponsored placement
CREATE TABLE sponsored_placements (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id     uuid NOT NULL REFERENCES organisations(id),
  context    text NOT NULL,                    -- e.g. 'search:root-canal:bengaluru'
  label      text NOT NULL DEFAULT 'Sponsored' CHECK (label = 'Sponsored'),
  starts_at  timestamptz NOT NULL,
  ends_at    timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (ends_at > starts_at)
);
